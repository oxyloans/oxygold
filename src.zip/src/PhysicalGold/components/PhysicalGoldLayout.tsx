import React, { useState, useEffect } from "react";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";
import { fetchMainCategories } from "../physicalGoldService";
import { Category } from "../physicalGoldData";
import LoadingSpinner from "./LoadingSpinner";

const PhysicalGoldLayout: React.FC = () => {
    const [categories, setCategories] = useState<Category[]>([]);
    const [categoriesLoaded, setCategoriesLoaded] = useState(false);
    const [selectedCategoryId, setSelectedCategoryId] = useState<string | undefined>();
    const navigate = useNavigate();
    const location = useLocation();

    useEffect(() => {
        fetchMainCategories()
            .then((data) => { setCategories(data); setCategoriesLoaded(true); })
            .catch((error) => { console.error("Failed to load layout categories:", error); setCategoriesLoaded(true); });
    }, []);

    useEffect(() => {
        const state = location.state as any;
        if (state?.selectedCategory) {
            setSelectedCategoryId(state.selectedCategory);
        } else if (state?.categoryId) {
            setSelectedCategoryId(state.categoryId);
        } else if (state?.reset) {
            setSelectedCategoryId("__all__");
        } else if (location.pathname === '/physical-gold' || location.pathname === '/physical-gold/') {
            setSelectedCategoryId("__all__");
        } else {
            const match = location.pathname.match(/\/physical-gold\/category\/([^/]+)/);
            if (match && match[1]) {
                setSelectedCategoryId(decodeURIComponent(match[1]));
            } else {
                setSelectedCategoryId(undefined);
            }
        }
    }, [location.state, location.pathname]);

    const handleCategoryClick = (categoryId: string) => {
        if (categoryId === "__all__" || categoryId === "all") {
            setSelectedCategoryId("__all__");
            navigate("/physical-gold");
        } else {
            setSelectedCategoryId(categoryId);
            navigate(`/physical-gold/category/${encodeURIComponent(categoryId)}`);
        }
    };

    const handleLogoClick = () => {
        setSelectedCategoryId("__all__");
        navigate("/physical-gold");
        window.scrollTo(0, 0);
    };

    return (
        <div className="flex flex-col min-h-screen bg-background">
            <Header
                categories={categories}
                onCategoryClick={handleCategoryClick}
                onLogoClick={handleLogoClick}
                selectedCategoryId={selectedCategoryId}
            />
            <div className="flex-1">
                {categoriesLoaded
                    ? <Outlet context={{ categories, selectedCategoryId, setSelectedCategoryId }} />
                    : <LoadingSpinner fullScreen message="Loading Collection..." />
                }
            </div>
            <Footer />
        </div>
    );
};

export default PhysicalGoldLayout;
