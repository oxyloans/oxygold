import React, { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
    AlertTriangle,
    ChevronRight,
    ChevronDown,
    CreditCard,
    Loader2,
    MapPin,
    Shield,
    ShoppingBag,
    Sparkles,
    Trash2,
    Wallet,
    X,
    ArrowLeft,
    Coins,
    Tag,
    CheckCircle2,
    Plus,
} from "lucide-react";
import { motion } from "framer-motion";
import { load } from "@cashfreepayments/cashfree-js";
import { QuantitySelector } from "./components/ui/QuantitySelector";
import { useCart } from "./CartContext";
import {
    fetchAddresses,
    createOrder,
    fetchWalletBalance,
    confirmOrder,
    getUserProfile,
} from "./physicalGoldService";

/* ────────────────────────────────────────────────────────── */
/*  Types                                                     */
/* ────────────────────────────────────────────────────────── */
interface Address {
    id: string;
    type: "Home" | "Work" | "Other";
    flatNo: string;
    landMark: string;
    address: string;
    pinCode: string;
    state: string;
    latitude: string;
    longitude: string;
}

interface PageState {
    addresses: Address[];
    selectedAddressId: string;
    paymentMode: "WALLET" | "CASHFREE" | "COD";
    walletBalance: number | null;
    loadingAddresses: boolean;
    loadingCheckout: boolean;
    orderSuccess: { orderNumber: string } | null;
    incrementingId: string | null;
    decrementingId: string | null;
    cartError: string;
    walletConfirmOpen: boolean;
    removeConfirmVariantId: string | null;
    confirmOrderModalOpen: boolean;
    orderId: string | number | null;
    paymentSessionId: string | null;
    txnId: string | null;
    profileReminderOpen: boolean;
    checkoutStep: "cart" | "checkout";
    successModalOpen: boolean;
}

/* ────────────────────────────────────────────────────────── */
/*  Helper                                                    */
/* ────────────────────────────────────────────────────────── */
const formatINR = (v: number) =>
    new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 0,
    }).format(v);

/* ────────────────────────────────────────────────────────── */
/*  Confirmation Modal                                        */
/* ────────────────────────────────────────────────────────── */
interface ConfirmModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    title: string;
    description: React.ReactNode;
    confirmLabel: string;
    confirmClassName?: string;
    loading?: boolean;
}

interface SuccessModalProps {
    isOpen: boolean;
    onClose: () => void;
    orderNumber: string;
}

const ConfirmModal: React.FC<ConfirmModalProps> = ({
    isOpen, onClose, onConfirm, title, description, confirmLabel, confirmClassName, loading,
}) => {
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            <div className="absolute inset-0 bg-black/30" onClick={onClose} />
            <div className="relative w-full max-w-sm rounded-xl border border-[#E8E0D5] bg-white shadow-2xl overflow-hidden">
                <div className="px-5 py-5">
                    <button
                        type="button"
                        onClick={onClose}
                        className="cursor-pointer absolute right-4 top-4 flex h-7 w-7 items-center justify-center rounded-full border border-[#E8E0D5] bg-[#F5F2EE] text-[#8A8A8A] transition hover:bg-[#EDE9E2]"
                    >
                        <X className="h-3.5 w-3.5" />
                    </button>
                    <div className="flex items-start gap-3 mb-3">
                        <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                            <AlertTriangle className="h-4 w-4" />
                        </div>
                        <h3 className="text-[14px] font-semibold text-[#1A1A1A] leading-snug pt-1">{title}</h3>
                    </div>
                    <div className="mb-5 pl-12 text-[13px] text-[#6B6B6B] leading-relaxed">{description}</div>
                    <div className="flex gap-2">
                        <button
                            type="button"
                            onClick={onClose}
                            className="cursor-pointer flex-1 rounded-lg border border-[#E8E0D5] bg-white px-4 py-2 text-[12px] font-medium text-[#6B6B6B] transition hover:bg-[#F5F2EE]"
                        >
                            Cancel
                        </button>
                        <button
                            type="button"
                            disabled={loading}
                            onClick={onConfirm}
                            className={`cursor-pointer flex-1 inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-[12px] font-medium transition disabled:opacity-60 ${confirmClassName ?? "bg-[#8B6914] text-white hover:bg-[#7A5C10]"}`}
                        >
                            {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : confirmLabel}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

const SuccessModal: React.FC<SuccessModalProps> = (props) => {
    if (!props.isOpen) return null;
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            <div className="absolute inset-0 bg-black/30" />
            <div className="relative w-full max-w-sm rounded-xl border border-[#E8E0D5] bg-white shadow-2xl overflow-hidden">
                <div className="px-5 py-5">
                    <div className="flex items-start gap-3 mb-3">
                        <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
                            <Shield className="h-4 w-4" />
                        </div>
                        <h3 className="text-[14px] font-semibold text-[#1A1A1A] leading-snug pt-1">Order Confirmed</h3>
                    </div>
                    <div className="mb-5 pl-12 text-[13px] text-[#6B6B6B] leading-relaxed">
                        Your order has been confirmed successfully.
                    </div>
                    <div className="flex gap-2">
                        <button
                            type="button"
                            onClick={props.onClose}
                            className="cursor-pointer flex-1 rounded-lg border border-[#E8E0D5] bg-white px-4 py-2 text-[12px] font-medium text-[#6B6B6B] transition hover:bg-[#F5F2EE]"
                        >
                            Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

/* ────────────────────────────────────────────────────────── */
/*  CartPage                                                  */
/* ────────────────────────────────────────────────────────── */
const CartPage: React.FC = () => {
    const navigate = useNavigate();

    const {
        cartItems,
        incrementQuantity,
        decrementQuantity,
        removeFromCart,
        clearCart,
        refreshCart,
        totalItems,
        cartSubtotal,
        totalGstCharges,
        totalMakingCharges,
        totalPayableAmount,
        deliveryFee,
        deliveryDistanceKm,
        ratePerKm,
        totalDiscountAmount,
        totalDiscountPercentage,
    } = useCart();

    const [showBreakdown, setShowBreakdown] = useState(false);
    const [showDiscountModal, setShowDiscountModal] = useState(false);
    const discountModalShownRef = useRef(false);
    const priceBreakdownRef = useRef<HTMLDivElement | null>(null);

    const hasSilverItems = cartItems.some(
        (item) =>
            /silver/i.test(item.product?.productName || "") ||
            /silver/i.test(item.variant?.purity || "")
    );
    const hasGoldItems = cartItems.some(
        (item) =>
            !(/silver/i.test(item.product?.productName || "")) &&
            !(/silver/i.test(item.variant?.purity || ""))
    );
    const isSilverCart = hasSilverItems;
    const metalName = hasSilverItems ? "Silver" : "Gold";
    const [s, setS] = useState<PageState>({
        addresses: [],
        selectedAddressId: "",
        paymentMode: "CASHFREE",
        walletBalance: null,
        loadingAddresses: false,
        loadingCheckout: false,
        orderSuccess: null,
        incrementingId: null,
        decrementingId: null,
        cartError: "",
        walletConfirmOpen: false,
        removeConfirmVariantId: null,
        confirmOrderModalOpen: false,
        orderId: null,
        paymentSessionId: null,
        txnId: null,
        profileReminderOpen: false,
        checkoutStep: "cart",
        successModalOpen: false,
    });

    const patch = useCallback(
        (partial: Partial<PageState>) => setS((prev) => ({ ...prev, ...partial })),
        []
    );

    useEffect(() => {
        if (totalDiscountAmount <= 0 || cartItems.length === 0) {
            setShowDiscountModal(false);
            return;
        }

        if (!discountModalShownRef.current) {
            const timer = window.setTimeout(() => {
                setShowDiscountModal(true);
                discountModalShownRef.current = true;
            }, 600);
            return () => window.clearTimeout(timer);
        }
    }, [totalDiscountAmount, cartItems.length]);

    useEffect(() => {
        const stored = localStorage.getItem("user");
        if (!stored) return;
        const uid = JSON.parse(stored).data.userId;
        if (!uid) return;

        (async () => {
            patch({ loadingAddresses: true });
            try {
                const [addrResult, balResult] = await Promise.allSettled([
                    fetchAddresses(uid),
                    fetchWalletBalance(uid),
                ]);


                const addrRes = addrResult.status === "fulfilled" ? addrResult.value : null;
                const balRes = balResult.status === "fulfilled" ? balResult.value : null;

                const mapped: Address[] = (addrRes?.data.reverse() || addrRes || []).map((a: any) => ({
                    id: String(a.id),
                    type: a.type || "Home",
                    flatNo: a.flatNo || "",
                    landMark: a.landMark || "",
                    address: a.address || "",
                    pinCode: a.pinCode || "",
                    state: a.state || "",
                    latitude: a.latitude || "",
                    longitude: a.longitude || "",
                }));

                const preferredDefault = mapped.find((a) => a.latitude && a.longitude) ?? mapped[0];

                patch({
                    addresses: mapped,
                    selectedAddressId: preferredDefault?.id ?? "",
                    walletBalance: balRes?.success ? (balRes.data?.balance ?? 0) : null,
                    loadingAddresses: false,
                });
            } catch (err) {
                console.error("Cart init error:", err);
                patch({ loadingAddresses: false });
            }
        })();
    }, []);

    useEffect(() => {
        if (!s.selectedAddressId) return;

        const syncAddressCart = async () => {
            const ok = await refreshCart(s.selectedAddressId);
            if (!ok) {
                patch({
                    cartError: "This address is missing location coordinates. Please update the address and capture current location to continue."
                });
            } else {
                patch({ cartError: "" });
            }
        };

        syncAddressCart();
    }, [s.selectedAddressId, refreshCart, patch]);

    const handleIncrement = useCallback(
        async (variantId: string) => {
            patch({ incrementingId: variantId });
            try { await incrementQuantity(variantId); }
            finally { patch({ incrementingId: null }); }
        },
        [incrementQuantity, patch]
    );

    const handleDecrement = useCallback(
        async (variantId: string, cartId: number | undefined) => {
            patch({ decrementingId: variantId });
            try { await decrementQuantity(variantId, cartId); }
            finally { patch({ decrementingId: null }); }
        },
        [decrementQuantity, patch]
    );

    const requestRemove = (variantId: string) => patch({ removeConfirmVariantId: variantId });

    const selectAddress = useCallback((addressId: string) => {
        patch({ selectedAddressId: addressId });
        refreshCart(addressId);
    }, [patch, refreshCart]);

    const confirmRemove = () => {
        if (s.removeConfirmVariantId) removeFromCart(s.removeConfirmVariantId);
        patch({ removeConfirmVariantId: null });
    };

    const handleCheckoutClick = () => {
        if (!s.selectedAddressId) return;
        const selectedAddr = s.addresses.find((a) => a.id === s.selectedAddressId);
        const missingLocation = !!selectedAddr && (!selectedAddr.latitude || !selectedAddr.longitude);

        if (missingLocation) {
            patch({
                cartError: "This address is missing location coordinates. Please update the address and capture current location to continue."
            });
            return;
        }

        if (s.paymentMode === "WALLET") patch({ walletConfirmOpen: true });
        else executeCheckout();
    };

    const executeCheckout = async () => {
        patch({ walletConfirmOpen: false, loadingCheckout: true });
        const stored = localStorage.getItem("user");
        if (!stored) return;
        try {
            const userId = JSON.parse(stored)?.data?.userId;
            if (!userId) { alert("Session expired. Please login again."); return; }

            try {
                const profileRes = await getUserProfile(userId);
                const profile = profileRes?.data?.body || profileRes?.data || profileRes;
                if (!profile?.firstName) {
                    patch({ profileReminderOpen: true, loadingCheckout: false });
                    return;
                }
            } catch {
                patch({ profileReminderOpen: true, loadingCheckout: false });
                return;
            }

            const redirectionUrl = s.paymentMode === "CASHFREE"
                ? `${window.location.origin}/physical-gold/payment-status`
                : undefined;

            const res = await createOrder({
                userId,
                addressId: parseInt(s.selectedAddressId),
                notes: "Physical Gold Order",
                paymentMode: s.paymentMode,
                ...(redirectionUrl && { returnUrl: redirectionUrl }),
            });

            if (res.success) {
                const orderId = res.data.id || res.data.orderId;
                const orderNumber = res.data.orderNumber;

                if (s.paymentMode === "WALLET") {
                    clearCart();
                    navigate(`/physical-gold/profile?tab=orders`);
                    patch({ loadingCheckout: false });
                } else if (s.paymentMode === "CASHFREE") {
                    patch({
                        orderId,
                        orderSuccess: { orderNumber },
                        paymentSessionId: res.data.paymentSessionId,
                        txnId: res.data.txnId,
                        confirmOrderModalOpen: true,
                        loadingCheckout: false,
                    });
                } else {
                    patch({ loadingCheckout: false, successModalOpen: true, orderSuccess: { orderNumber } });
                }
            }
        } catch (err: any) {
            alert(err.message || "Checkout failed. Please try again.");
            patch({ loadingCheckout: false });
        }
    };

    const handleConfirmOrder = async () => {
        if (!s.orderId) return;
        patch({ loadingCheckout: true });
        try {
            // await confirmOrder(s.orderId);
            if (s.paymentMode === "CASHFREE" && s.paymentSessionId) {
                const cashfree = await load({ mode: "production" });
                const orderNumber = s.orderSuccess?.orderNumber || "";
                cashfree.checkout({
                    paymentSessionId: s.paymentSessionId,
                    redirectTarget: "_self",
                    returnUrl: `${window.location.origin}/physical-gold/payment-status?order_id=${s.txnId}&internal_id=${s.orderId}&order_number=${orderNumber}`,
                });
            } else {
                clearCart();
                const orderNumber = s.orderSuccess?.orderNumber || "";
                navigate(`/physical-gold/payment-status?order_id=${s.orderId}&internal_id=${s.orderId}&order_number=${orderNumber}`);
            }
        } catch (err: any) {
            alert(err.message || "Confirmation failed. Please try again.");
        } finally {
            patch({ loadingCheckout: false, confirmOrderModalOpen: false });
        }
    };

    /* ── Empty State ── */
    if (cartItems.length === 0) {
        return (
            <div className="min-h-screen bg-[#F5F2EE]">
                <div className="flex items-center justify-center min-h-[80vh] px-4">
                    <div className="text-center max-w-sm mx-auto space-y-5">
                        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-[#E8E0D5] bg-white shadow-sm">
                            <ShoppingBag className="h-7 w-7 text-[#D1C7BB]" strokeWidth={1.5} />
                        </div>
                        <div>
                            <h2 className="text-[18px] font-semibold text-[#1A1A1A] mb-2">Your cart is empty</h2>
                            <p className="text-[13px] text-[#8A8A8A] leading-relaxed">Discover our collection of certified hallmarked gold jewellery.</p>
                        </div>
                        <button
                            onClick={() => navigate("/physical-gold")}
                            className="cursor-pointer inline-flex items-center gap-2 rounded-lg bg-[#8B6914] px-6 py-2.5 text-[12px] font-medium text-white hover:bg-[#7A5C10] transition"
                        >
                            <Sparkles className="h-3.5 w-3.5" /> Browse Collection
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    const itemToRemove = cartItems.find((ci) => ci.variant.id === s.removeConfirmVariantId);

    return (
        <div className="min-h-screen bg-[#F5F2EE] text-[#1A1A1A]">

            {/* Modals */}
            <ConfirmModal
                isOpen={s.walletConfirmOpen}
                onClose={() => patch({ walletConfirmOpen: false })}
                onConfirm={executeCheckout}
                loading={s.loadingCheckout}
                title="Confirm Wallet Payment"
                confirmLabel="Yes, Pay Now"
                confirmClassName="bg-[#8B6914] text-white hover:bg-[#7A5C10]"
                description={
                    <div className="space-y-3">
                        <p>You're about to pay <span className="font-semibold text-[#8B6914]">{formatINR(totalPayableAmount)}</span> from your OxyGold Wallet.</p>
                        <div className="rounded-lg border border-[#E8E0D5] bg-[#F5F2EE] px-3 py-2.5 flex items-center justify-between">
                            <div className="flex items-center gap-2 text-[11px] font-medium text-[#8A8A8A] uppercase tracking-wider">
                                <Wallet className="h-3.5 w-3.5 text-[#8B6914]" /> Balance
                            </div>
                            <span className={`text-[13px] font-semibold ${s.walletBalance !== null && s.walletBalance >= totalPayableAmount ? "text-emerald-600" : "text-rose-500"}`}>
                                {s.walletBalance !== null ? formatINR(s.walletBalance) : "—"}
                            </span>
                        </div>
                    </div>
                }
            />
            <ConfirmModal
                isOpen={!!s.removeConfirmVariantId}
                onClose={() => patch({ removeConfirmVariantId: null })}
                onConfirm={confirmRemove}
                title="Remove Item"
                confirmLabel="Remove"
                confirmClassName="bg-rose-500 text-white hover:bg-rose-600"
                description={<p>Remove <span className="font-semibold">{itemToRemove?.product.productName}</span> from your cart?</p>}
            />
            <ConfirmModal
                isOpen={s.confirmOrderModalOpen}
                onClose={() => patch({ confirmOrderModalOpen: false })}
                onConfirm={handleConfirmOrder}
                loading={s.loadingCheckout}
                title="Confirm Your Order"
                confirmLabel="Confirm & Pay"
                confirmClassName="bg-[#8B6914] text-white hover:bg-[#7A5C10]"
                description={<p>Please review your order summary to proceed with payment.</p>}
            />
            <SuccessModal
                isOpen={s.successModalOpen}
                orderNumber={s.orderSuccess?.orderNumber ?? ""}
                onClose={() => { clearCart(); patch({ successModalOpen: false }); navigate(`/physical-gold/profile?tab=orders`); }}
            />
            <ConfirmModal
                isOpen={s.profileReminderOpen}
                onClose={() => patch({ profileReminderOpen: false })}
                onConfirm={() => { patch({ profileReminderOpen: false }); navigate("/physical-gold/profile"); }}
                title="Complete Your Profile"
                confirmLabel="Go to Profile"
                confirmClassName="bg-[#8B6914] text-white hover:bg-[#7A5C10]"
                description={<p>We need your profile details to process this order.</p>}
            />

            <main className="pt-24 md:pt-36 lg:pt-36 pb-16 max-w-5xl mx-auto px-4 sm:px-4">

                {/* Back to Store */}
                <button
                    onClick={() => navigate("/physical-gold")}
                    className="mb-2 mt-2 cursor-pointer inline-flex items-center gap-1.5 text-[14px] font-medium text-[#8A8A8A] hover:text-[#8B6914] transition"
                >
                    <ArrowLeft className="h-3.5 w-3.5" /> Back to Store
                </button>

                {/* Page Title + Breadcrumb */}
                <div className="mb-4">
                    <h1 className="text-[20px] font-semibold text-[#1A1A1A]">
                        {s.checkoutStep === "cart" ? `Shopping Cart (${totalItems})` : "Checkout"}
                    </h1>
                    <div className="flex pt-1.5 items-center gap-3 text-[14px] text-[#8A8A8A]">
                        <span
                            className={`cursor-pointer ${s.checkoutStep === "cart" ? "text-[#8B6914] font-semibold" : ""}`}
                            onClick={() => patch({ checkoutStep: "cart" })}
                        >
                            01 Shopping Cart
                        </span>
                        <span className="text-[#D1C7BB]">›</span>
                        <span className={s.checkoutStep === "checkout" ? "text-[#8B6914] font-semibold" : ""}>
                            02 Address & Payment
                        </span>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6 items-start">

                    {/* LEFT — Cart Items or Checkout */}
                    <div className="space-y-3">
                        {s.checkoutStep === "cart" ? (
                            <>
                                <div className="space-y-3 max-h-[380px] sm:max-h-[420px] overflow-y-auto pr-1.5 overscroll-contain scroll-smooth [scrollbar-width:thin] [scrollbar-color:#D1C7BB_transparent] [&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-track]:bg-[#F5F2EE] [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-thumb]:bg-[#D1C7BB] [&::-webkit-scrollbar-thumb]:rounded-full hover:[&::-webkit-scrollbar-thumb]:bg-[#8B6914]">
                                    {cartItems.map(({ cartId, product, variant, quantity }) => {
                                        const lineTotal = variant.price * quantity;
                                        return (
                                            <div
                                                key={variant.id}
                                                className="flex items-center gap-4 p-4 rounded-xl border border-[#E8E0D5] bg-white hover:border-[#C9B87A] transition group"
                                            >
                                                {/* Image */}
                                                <button
                                                    type="button"
                                                    onClick={() => product.id && navigate(`/physical-gold/product/${product.id}`)}
                                                    className="h-20 w-20 flex-shrink-0 rounded-lg overflow-hidden bg-[#F5F2EE] border border-[#E8E0D5] cursor-pointer hover:border-[#8B6914]/60 transition group/img"
                                                    title={`View ${product.productName}`}
                                                >
                                                    <img
                                                        src={product.imageUrl}
                                                        alt={product.productName}
                                                        className="h-full w-full object-cover mix-blend-multiply transition-transform duration-300 group-hover/img:scale-105"
                                                    />
                                                </button>

                                                {/* Info */}
                                                <div className="flex-1 min-w-0">
                                                    <div className="flex items-start justify-between gap-2">
                                                        <button
                                                            type="button"
                                                            onClick={() => product.id && navigate(`/physical-gold/product/${product.id}`)}
                                                            className="text-left cursor-pointer group/title"
                                                        >
                                                            <h3 className="text-[14px] font-semibold text-[#1A1A1A] leading-snug group-hover/title:text-[#8B6914] transition-colors">
                                                                {product.productName}
                                                            </h3>
                                                        </button>
                                                        <button
                                                            onClick={() => requestRemove(variant.id)}
                                                            className="shrink-0 p-1 text-[#D1C7BB] hover:text-rose-500 transition opacity-0 group-hover:opacity-100 cursor-pointer"
                                                            title="Remove item"
                                                        >
                                                            <Trash2 size={14} />
                                                        </button>
                                                    </div>
                                                    <p className="text-[11px] text-[#8A8A8A] mt-0.5">
                                                        {variant.purity} {" "}
                                                        {variant.weight}g
                                                        {/* {variant.size || "Standard"} */}
                                                    </p>
                                                    <div className="flex items-center justify-between mt-3">
                                                        <QuantitySelector
                                                            quantity={quantity}
                                                            onIncrease={() => handleIncrement(variant.id)}
                                                            onDecrease={() => handleDecrement(variant.id, cartId)}
                                                            disabled={s.incrementingId === variant.id || s.decrementingId === variant.id}
                                                        />
                                                        <span className="text-[15px] font-semibold text-[#8B6914]">
                                                            ₹{lineTotal.toLocaleString("en-IN")}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>

                                {cartItems.length > 0 && (
                                    <div className="pt-3 flex justify-center items-center">
                                        <button
                                            type="button"
                                            onClick={() => navigate("/physical-gold")}
                                            className="cursor-pointer inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-[#E8E0D5] bg-white text-[13px] font-semibold text-[#8B6914] hover:bg-[#F5EDD6]/40 hover:border-[#8B6914]/50 hover:shadow-xs transition-all active:scale-95 shadow-2xs"
                                        >
                                            <ShoppingBag size={16} className="text-[#8B6914] shrink-0" />
                                            <span>Continue Shopping</span>
                                        </button>
                                    </div>
                                )}
                            </>
                        ) : (
                            <div className="space-y-5">
                                {/* Delivery Address */}
                                <div className="bg-white border border-[#E8E0D5] rounded-xl p-5">
                                    <div className="flex items-center justify-between mb-4">
                                        <h3 className="text-[14px] font-semibold text-[#1A1A1A]">Delivery Address</h3>
                                        <button
                                            onClick={() => navigate("/physical-gold/profile?tab=address")}
                                            className="text-[11px] font-medium text-[#8B6914] hover:underline"
                                        >
                                            Manage Addresses
                                        </button>
                                    </div>
                                    <div className="space-y-2 max-h-[17rem] overflow-y-auto pr-1.5 overscroll-contain scroll-smooth [scrollbar-width:thin] [scrollbar-color:#D1C7BB_transparent] [&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-track]:bg-[#F5F2EE] [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-thumb]:bg-[#D1C7BB] [&::-webkit-scrollbar-thumb]:rounded-full hover:[&::-webkit-scrollbar-thumb]:bg-[#8B6914]">
                                        {s.addresses.map((addr) => {
                                            const missingLocation = !addr.latitude || !addr.longitude;
                                            return (
                                                <button
                                                    key={addr.id}
                                                    onClick={() => selectAddress(addr.id)}
                                                    className={`w-full text-left px-4 py-3 rounded-lg border transition-all ${s.selectedAddressId === addr.id ? "border-[#8B6914] bg-[#F5EDD6]/30" : "border-[#E8E0D5] hover:border-[#C9B87A]"}`}
                                                >
                                                    <div className="flex items-start gap-3">
                                                        <MapPin size={14} className={`mt-0.5 shrink-0 ${s.selectedAddressId === addr.id ? "text-[#8B6914]" : "text-[#D1C7BB]"}`} />
                                                        <div className="flex-1 min-w-0">
                                                            <p className="text-[11px] font-semibold text-[#8A8A8A] uppercase tracking-wider mb-0.5">{addr.type}</p>
                                                            <p className="text-[13px] font-medium text-[#1A1A1A]">{addr.address}</p>
                                                            <p className="text-[11px] text-[#8A8A8A]">{addr.landMark}, {addr.flatNo}</p>
                                                            {missingLocation && (
                                                                <p className="text-[10px] text-amber-600 mt-1 flex items-center gap-1">
                                                                    <AlertTriangle size={10} /> Location not captured — <button onClick={() => navigate("/physical-gold/profile?tab=address")} className="underline font-semibold">edit the address</button>
                                                                </p>
                                                            )}
                                                        </div>
                                                    </div>
                                                </button>
                                            );
                                        })}
                                    </div>
                                </div>

                                {/* Payment Method */}
                                <div className="bg-white border border-[#E8E0D5] rounded-xl p-5">
                                    <h3 className="text-[14px] font-semibold text-[#1A1A1A] mb-4">Payment Method</h3>
                                    <div className="flex flex-col sm:grid sm:grid-cols-2 gap-3">
                                        {(["CASHFREE", "COD"] as const).map((mode) => (
                                            <button
                                                key={mode}
                                                onClick={() => patch({ paymentMode: mode })}
                                                className={`flex items-center gap-3 px-4 py-3.5 rounded-lg border transition-all text-left w-full ${s.paymentMode === mode ? "border-[#8B6914] bg-[#F5EDD6]/30" : "border-[#E8E0D5] hover:border-[#C9B87A]"}`}
                                            >
                                                <div className={`h-9 w-9 rounded-lg flex items-center justify-center shrink-0 ${s.paymentMode === mode ? "bg-[#8B6914] text-white" : "bg-[#F5F2EE] text-[#D1C7BB]"}`}>
                                                    {mode === "COD" ? <Coins size={16} /> : <CreditCard size={16} />}
                                                </div>
                                                <div className="min-w-0">
                                                    <p className={`text-[13px] font-semibold leading-tight ${s.paymentMode === mode ? "text-[#8B6914]" : "text-[#1A1A1A]"}`}>
                                                        {mode === "COD" ? "Cash on Delivery" : "Online Payment"}
                                                    </p>
                                                    <p className="text-[11px] text-[#8A8A8A] mt-0.5">
                                                        {mode === "COD" ? "Pay when order arrives" : "UPI, Cards, Net Banking"}
                                                    </p>
                                                </div>
                                                {s.paymentMode === mode && (
                                                    <div className="ml-auto shrink-0 h-4 w-4 rounded-full bg-[#8B6914] flex items-center justify-center">
                                                        <div className="h-1.5 w-1.5 rounded-full bg-white" />
                                                    </div>
                                                )}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* RIGHT — Order Summary */}
                    <div className="lg:sticky lg:top-24">
                        <div className="bg-white border border-[#E8E0D5] rounded-xl p-5 shadow-sm">
                            <h2 className="text-[15px] font-semibold text-[#1A1A1A] mb-4">Order Summary</h2>

                            {/* Products — name and quantity from cart response */}
                            <div className="mb-4 border-b border-[#F0EBE1] pb-4">
                                {cartItems.length > 3 && (
                                    <div className="flex items-center justify-between pb-1.5 text-[11px] text-[#8A8A8A]">
                                        <span>Items ({cartItems.length})</span>
                                        <span className="text-[10px] text-[#8B6914] font-medium">Scroll to view all</span>
                                    </div>
                                )}
                                <div
                                    className={`space-y-2 ${
                                        cartItems.length > 3
                                            ? "max-h-[135px] overflow-y-auto pr-1.5 overscroll-contain scroll-smooth [scrollbar-width:thin] [scrollbar-color:#D1C7BB_transparent] [&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-track]:bg-[#F5F2EE] [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-thumb]:bg-[#D1C7BB] [&::-webkit-scrollbar-thumb]:rounded-full hover:[&::-webkit-scrollbar-thumb]:bg-[#8B6914]"
                                            : ""
                                    }`}
                                >
                                    {cartItems.map(({ product, variant, quantity }) => (
                                        <div
                                            key={`summary-${variant.id}`}
                                            className="flex min-w-0 items-start justify-between gap-3"
                                        >
                                            <p
                                                className="min-w-0 flex-1 break-words text-[12px] font-medium leading-5 text-[#1A1A1A]"
                                                title={product.productName}
                                            >
                                                {product.productName}
                                            </p>
                                            <span className="shrink-0 rounded-md bg-[#F5F2EE] px-2 py-1 text-[11px] font-semibold text-[#6B6B6B]">
                                                Qty: {quantity}
                                            </span>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Price Breakdown Box */}
                            <div ref={priceBreakdownRef} className="rounded-xl border border-[#F0EBE1] bg-[#FAF8F5] p-4 mb-5 space-y-2.5">
                                <div className="flex justify-between items-center text-[13px]">
                                    <span className="text-[#6B6B6B] font-medium">Subtotal ({totalItems} {totalItems === 1 ? 'item' : 'items'})</span>
                                    <span className="font-semibold text-[#1A1A1A]">₹{cartSubtotal.toLocaleString("en-IN")}</span>
                                </div>
                                <div className="flex justify-between items-center text-[12px]">
                                    <span className="text-[#8A8A8A]">Making Charges</span>
                                    <span className="font-medium text-[#1A1A1A]">₹{totalMakingCharges.toLocaleString("en-IN")}</span>
                                </div>
                                <div className="flex justify-between items-center text-[12px]">
                                    <span className="text-[#8A8A8A]">GST (3%)</span>
                                    <span className="font-medium text-[#1A1A1A]">₹{totalGstCharges.toLocaleString("en-IN")}</span>
                                </div>

                                {/* Delivery Fee: Display ONLY if distance > 0 OR fee > 0 */}
                                {((deliveryDistanceKm !== null && deliveryDistanceKm > 0) || deliveryFee > 0) && (
                                    <div>
                                        <div className="flex justify-between items-center text-[12px]">
                                            <span className="text-[#8A8A8A]">
                                                Delivery{deliveryDistanceKm !== null && deliveryDistanceKm > 0 ? ` (${deliveryDistanceKm} km)` : ""}
                                            </span>
                                            <span className="font-medium text-[#1A1A1A]">₹{deliveryFee.toLocaleString("en-IN")}</span>
                                        </div>
                                        {ratePerKm !== null && ratePerKm > 0 && deliveryDistanceKm !== null && deliveryDistanceKm > 0 && (
                                            <p className="text-[10px] text-[#8A8A8A] text-right mt-0.5">₹{ratePerKm}/km delivery rate</p>
                                        )}
                                    </div>
                                )}

                                {totalDiscountAmount > 0 && (
                                    <div
                                        onClick={() => setShowDiscountModal(true)}
                                        className="flex justify-between items-center text-[12px] cursor-pointer group/disc hover:bg-emerald-50/60 rounded-md -mx-1 px-1 py-0.5 transition-colors"
                                        title="Click to view discount details"
                                    >
                                        <span className="text-emerald-600 flex items-center gap-1 font-medium">
                                            Discount
                                            {/* {totalDiscountPercentage > 0 && (
                                                <span className="inline-flex items-center rounded-full bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-700">
                                                    -{totalDiscountPercentage}%
                                                </span>
                                            )} */}
                                        </span>
                                        <span className="font-semibold text-emerald-600 flex items-center gap-1">
                                            -₹{totalDiscountAmount.toLocaleString("en-IN")}
                                            {/* <Sparkles size={11} className="text-emerald-500" /> */}
                                        </span>
                                    </div>
                                )}

                               {/* <div className="flex justify-between items-center text-[12px]">
                                    <span className="text-[#8A8A8A]">Insurance</span>
                                    <span className="font-medium text-[#1A1A1A]">Included</span>
                                </div> */}

                                <div className="border-t border-[#E8E0D5] pt-3 mt-3 flex justify-between items-center">
                                    <span className="text-[14px] font-semibold text-[#1A1A1A]">Total To Pay</span>
                                    <span className="text-[18px] font-bold text-[#8B6914]">
                                        ₹{totalPayableAmount.toLocaleString("en-IN")}
                                    </span>
                                </div>
                            </div>

                            {s.checkoutStep === "cart" ? (
                                <button
                                    onClick={() => patch({ checkoutStep: "checkout" })}
                                    className="w-full py-2.5 rounded-lg bg-[#8B6914] text-white text-[13px] font-medium hover:bg-[#7A5C10] transition flex items-center justify-center gap-2 group"
                                >
                                    Proceed to Checkout
                                    <ChevronRight size={14} className="group-hover:translate-x-0.5 transition-transform" />
                                </button>
                            ) : (() => {
                                const selectedAddr = s.addresses.find(a => a.id === s.selectedAddressId);
                                const missingLocation = selectedAddr && (!selectedAddr.latitude || !selectedAddr.longitude);
                                const locationMessage = s.cartError || (missingLocation ? "This address is missing location coordinates. Please edit the address and capture your current location to proceed." : "");
                                return (
                                    <>
                                        {locationMessage && (
                                            <div className="mb-3 flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5">
                                                <AlertTriangle size={13} className="text-amber-600 shrink-0 mt-0.5" />
                                                <p className="text-[11px] text-amber-700 leading-snug">
                                                    {locationMessage.includes("edit the address") ? (
                                                        <>
                                                            {locationMessage.split("Please ")[0]}
                                                            <button onClick={() => navigate("/physical-gold/profile?tab=address")} className="underline font-semibold">edit the address</button>
                                                            {locationMessage.includes("to proceed") ? " to proceed." : ""}
                                                        </>
                                                    ) : (
                                                        locationMessage
                                                    )}
                                                </p>
                                            </div>
                                        )}
                                        <button
                                            disabled={!s.selectedAddressId || s.loadingCheckout || !!missingLocation}
                                            onClick={handleCheckoutClick}
                                            className="w-full py-2.5 rounded-lg bg-[#8B6914] text-white text-[13px] font-medium hover:bg-[#7A5C10] transition disabled:opacity-50 flex items-center justify-center"
                                        >
                                            {s.loadingCheckout
                                                ? <Loader2 size={15} className="animate-spin" />
                                                : "Place Order"}
                                        </button>
                                    </>
                                );
                            })()}

                            <div className="mt-4 flex items-center justify-center gap-1.5 text-[11px] text-[#8A8A8A]">
                                <Shield size={11} className="text-[#8B6914]" />
                                Secure & Encrypted Checkout
                            </div>
                        </div>
                    </div>

                </div>
            </main>
            {/* 100% GST Paid by OxyGold.ai Discount Modal */}
            {showDiscountModal && totalDiscountAmount > 0 && (
                <div
                    className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 cursor-pointer"
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="discount-title"
                    onClick={() => setShowDiscountModal(false)}
                >
                    <motion.div
                        initial={{ opacity: 0, scale: 0.92, y: 24 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                        className={`relative w-full max-w-sm overflow-hidden rounded-[28px] bg-gradient-to-b p-6 sm:p-7 text-center shadow-2xl ring-1 cursor-default ${
                            isSilverCart
                                ? "from-slate-50 via-white to-slate-50 ring-slate-200/60"
                                : "from-amber-50 via-white to-amber-50 ring-amber-200/60"
                        }`}
                        onClick={(e) => e.stopPropagation()}
                    >
                        {/* ambient glow */}
                        <motion.div
                            animate={{ scale: [1, 1.15, 1], opacity: [0.3, 0.5, 0.3] }}
                            transition={{ duration: 4, repeat: Infinity }}
                            className={`pointer-events-none absolute -left-10 -top-10 h-40 w-40 rounded-full blur-3xl ${
                                isSilverCart ? "bg-slate-200/60" : "bg-amber-200/50"
                            }`}
                        />
                        <motion.span
                            animate={{ y: [0, -6, 0], rotate: [0, 12, 0] }}
                            transition={{ duration: 3, repeat: Infinity }}
                            className={`pointer-events-none absolute left-7 top-6 ${isSilverCart ? "text-slate-400" : "text-amber-300"}`}
                        >
                            <Sparkles size={18} />
                        </motion.span>

                        <button
                            type="button"
                            onClick={(e) => {
                                e.stopPropagation();
                                setShowDiscountModal(false);
                            }}
                            className="absolute right-4 top-4 z-20 flex h-8 w-8 cursor-pointer items-center justify-center rounded-full bg-white/80 text-[#8A8A8A] shadow-xs ring-1 ring-black/5 hover:bg-[#F5F2EE] hover:text-[#1A1A1A] transition-colors"
                            aria-label="Close"
                        >
                            <X size={16} />
                        </button>

                        <div className="relative z-10">
                            {/* Icon */}
                            <div
                                className={`mx-auto mb-3.5 flex h-13 w-13 items-center justify-center rounded-2xl shadow-lg ${
                                    isSilverCart
                                        ? "bg-gradient-to-br from-slate-500 to-slate-700 text-white shadow-slate-200"
                                        : "bg-gradient-to-br from-[#C29B27] to-[#9B7416] text-white shadow-amber-200"
                                }`}
                            >
                                <Tag size={24} />
                            </div>

                            {/* Top Badge */}
                            <span
                                className={`mb-2.5 inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-bold ${
                                    isSilverCart
                                        ? "border-slate-200 bg-slate-50 text-slate-700"
                                        : "border-amber-200 bg-amber-50 text-amber-700"
                                }`}
                            >
                                <CheckCircle2 size={12} className="text-emerald-600" /> 100% GST Paid by OxyGold.ai
                            </span>

                            <h2
                                id="discount-title"
                                className={`text-xl font-black ${isSilverCart ? "text-slate-800" : "text-[#8B6914]"}`}
                            >
                                Congratulations! 🎉
                            </h2>
                            <p className="mt-1 text-[15px] font-bold text-[#1A1A1A]">
                                We are paying the GST amount on your behalf!
                            </p>
                            <p className="mt-2 text-[12px] leading-relaxed text-[#5A5A5A]">
                                For your {isSilverCart ? "silver" : metalName.toLowerCase()} purchase, <strong className="text-[#1A1A1A]">OxyGold.ai</strong> covers the complete government GST so you don't have to pay extra. The entire tax amount is waived as an instant discount!
                            </p>

                            {/* GST Breakdown Box */}
                            <div className="my-4 rounded-xl border border-[#EFE7DC] bg-[#FAF8F5] p-3.5 text-left text-[12px] space-y-2">
                                <div className="flex justify-between items-center text-[#5A5A5A]">
                                    <span>Government GST ({totalDiscountPercentage || 3}%)</span>
                                    <span className="font-semibold text-[#1A1A1A]">
                                        ₹{(totalGstCharges || totalDiscountAmount).toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                                    </span>
                                </div>
                                <div className="flex justify-between items-center text-emerald-700 font-semibold">
                                    <span className="flex items-center gap-1">
                                        <Tag size={11} /> OxyGold.ai GST {isSilverCart ? "Silver " : ""}Waiver:
                                    </span>
                                    <span>
                                        -₹{totalDiscountAmount.toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                                    </span>
                                </div>
                                <div className="border-t border-[#E8E0D5] pt-2 flex justify-between items-center">
                                    <span className="font-bold text-[#1A1A1A]">Your Net Tax Contribution</span>
                                    <span className="font-extrabold text-emerald-700 text-[12px]">
                                        ₹0.00 <span className="font-medium text-[10px] text-emerald-600">(Zero Extra Tax)</span>
                                    </span>
                                </div>
                            </div>

                            {/* Highlight Badges */}
                            <div className="mb-5 flex justify-center gap-2 flex-wrap">
                                <span className="inline-flex items-center gap-1 rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-[11px] font-bold text-emerald-700">
                                    <CheckCircle2 size={11} /> 100% Tax Covered
                                </span>
                                <span
                                    className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-bold ${
                                        isSilverCart
                                            ? "border-slate-200 bg-slate-100 text-slate-700"
                                            : "border-amber-200 bg-amber-100 text-amber-800"
                                    }`}
                                >
                                    <Sparkles size={11} /> Pure {isSilverCart ? "Silver" : metalName} Offer
                                </span>
                            </div>

                            <button
                                type="button"
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setShowDiscountModal(false);
                                }}
                                className={`w-full cursor-pointer rounded-full py-2.5 text-[13px] font-bold text-white shadow-lg transition hover:opacity-95 active:scale-[0.99] ${
                                    isSilverCart
                                        ? "bg-gradient-to-r from-slate-600 to-slate-800 shadow-slate-200"
                                        : "bg-gradient-to-r from-[#C29B27] to-[#9B7416] shadow-amber-200"
                                }`}
                            >
                                Awesome, Got it
                            </button>
                        </div>
                    </motion.div>
                </div>
            )}
        </div>
    );
};

export default CartPage;
