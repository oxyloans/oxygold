import React, { useCallback, useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import {
    ArrowLeft,
    CheckCircle2,
    History,
    Loader2,
    LogOut,
    MapPin,
    MapPinned,
    Pencil,
    Plus,
    Minus,
    Package,
    ChevronDown,
    ChevronUp,
    CreditCard,
    FileText,
    ShoppingBag,
    User,
    Wallet,
    Trash2,
    HelpCircle,
    MessageSquare,
    Send,
    CheckCheck,
    Paperclip,
    X,
    AlertTriangle,
    Star,
    ImagePlus,
    Truck,
} from "lucide-react";
import {
    addAddress,
    fetchAddresses,
    fetchWalletBalance,
    fetchWalletTransactions,
    getUserProfile,
    logout,
    saveUserProfile,
    updateAddress,
    deleteAddress,
    fetchUserOrders,
    getInvoicePreviewUrl,
    verifyPan,
    writeQuery,
    getAllQueries,
    cancelQuery,
    uploadQueryScreenshot,
    createRating,
    updateRating,
    fetchMyRatings,
    fetchRating,
    fetchRatingMedia,
    uploadRatingMedia,
    fetchOrderDeliveryTracking,
    retryOrderPayment,
    type DeliveryTracking,
    type ProductReview,
    type HelpdeskQuery,
} from "./physicalGoldService";
import { load } from "@cashfreepayments/cashfree-js";
import { type Order, type OrderItem, resolveS3ImageUrl } from "./physicalGoldData";

import PhysicalGoldHeader from "./components/Header";
import Toast, { ToastType } from "./components/Toast";
import Dropdown from "./components/Dropdown";
import TokenManager from "../utils/tokenManager";
import { validateEmail, validateMobileNumber, formatMobileNumber, validatePincode, getPincodeError, formatPincode } from "./utils/validations";

const DISPLAY_INR = (v: number) =>
    new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 0,
    }).format(v);

const getApiErrorMessage = (error: unknown, fallback: string) =>
    error instanceof Error && error.message ? error.message : fallback;

const normaliseAddress = (address: Pick<Address, "flatNo" | "landMark" | "address" | "pinCode" | "state">) =>
    [address.flatNo, address.landMark, address.address, address.pinCode, address.state]
        .map((value) => value.trim().replace(/\s+/g, " ").toLowerCase())
        .join("|");

const removeErrorKey = (errors: Record<string, string> | undefined, key: string): Record<string, string> => {
    const { [key]: _removed, ...rest } = (errors ?? {}) as Record<string, string>;
    return rest;
};

/* ────────────────────────────────────────────────────────── */
/*  Types                                                     */
/* ────────────────────────────────────────────────────────── */
interface Address {
    id: string;
    type: "Home" | "Work" | "Other";
    flatNo: string;
    landMark: string;
    address: string;
    pinCode: string;
    state: string;
    longitude: string;
    latitude: string;
}

type Tab = "info" | "address" | "wallet" | "orders" | "support";

interface PageState {
    activeTab: Tab;
    isEditingProfile: boolean;
    isSavingProfile: boolean;
    isProfileLoading: boolean;
    isVerifyingPan: boolean;
    profileForm: {
        firstName: string;
        lastName: string;
        email: string;
        alternativeNumber: string;
        whatsappNumber: string;
        mobileNumber: string;
        gender: string;
        panNumber: string;
        panVerified: boolean;
    };
    profileErrors: Record<string, string>;
    addresses: Address[];
    isAddressLoading: boolean;
    isAddingAddress: boolean;
    editingAddress: Address | null;
    addrForm: {
        flatNo: string;
        landMark: string;
        address: string;
        pinCode: string;
        state: string;
        type: Address["type"];
        latitude: string;
        longitude: string;
        typeDropdownOpen: boolean;
    };
    addrErrors: Record<string, string>;
    isFetchingLocation: boolean;
    locationError: string;
    walletBalance: number;
    walletTransactions: any[];
    isWalletLoading: boolean;
    orders: Order[];
    isOrdersLoading: boolean;
    expandedOrderId: number | null;
    deliveryTracking: Record<number, DeliveryTracking>;
    trackingLoadingOrderId: number | null;
    trackingErrorOrderId: number | null;
    toast: { message: string; type: ToastType } | null;
    deleteConfirmation: { show: boolean; addressId: string | null };
    // Support/Helpdesk
    queries: HelpdeskQuery[];
    isQueriesLoading: boolean;
    isSubmittingQuery: boolean;
    queryForm: { query: string; comments: string; file: File | null; };
    queryFormErrors: Record<string, string>;
    queryStatusFilter: string;
    showQueryForm: boolean;
    isUploadingFile: boolean;
    cancellingQueryId: number | null;
    cancelQueryConfirmation: {
        show: boolean;
        queryId: number | null;
        ticketNumber?: string;
    };
    profileIncompleteModal: boolean;
}

/* ────────────────────────────────────────────────────────── */
/*  Helpers                                                   */
/* ────────────────────────────────────────────────────────── */
const formatDate = (dateString: string) => {
    if (!dateString) return "—";
    return new Date(dateString).toLocaleDateString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
    });
};

const getStatusColor = (status?: string | null) => {
    switch (status?.toUpperCase()) {
        case "CONFIRMED":
        case "DELIVERED":
        case "COMPLETED":
        case "SUCCESS": return "text-emerald-700 bg-emerald-50";
        case "PENDING":
        case "PAYMENT_PENDING": return "text-amber-700 bg-amber-50";
        case "CANCELLED":
        case "FAILED": return "text-rose-700 bg-rose-50";
        case "ONLINE": return "text-blue-700 bg-blue-50";
        case "COD":
        case "CASH": return "text-purple-700 bg-purple-50";
        default: return "text-zinc-600 bg-zinc-100";
    }
};

const GET_USER_DATA = () => {
    try {
        const s = localStorage.getItem("user");
        return s ? JSON.parse(s) : null;
    } catch { return null; }
};

/* ────────────────────────────────────────────────────────── */
/*  Shared input styles                                       */
/* ────────────────────────────────────────────────────────── */
const inputCls =
    "w-full border border-[#E8E0D5] rounded-lg px-3 py-2 text-[13px] text-[#1A1A1A] bg-white placeholder-[#BEB5AA] outline-none focus:border-[#8B6914] focus:ring-2 focus:ring-[#8B6914]/10 transition";

const labelCls = "block text-[11px] font-semibold text-[#8A8A8A] mb-1";
const REVIEW_TITLE_MIN = 3;
const REVIEW_TEXT_MIN = 10;
const IMAGE_MAX_BYTES = 10 * 1024 * 1024;
const VIDEO_MAX_BYTES = 50 * 1024 * 1024;
const REVIEW_MEDIA_TYPES = ["image/jpeg", "image/png", "image/webp", "video/mp4", "video/webm"];
const REVIEW_RATING_LABELS = ["", "Poor", "Fair", "Good", "Very good", "Excellent"];

/* ────────────────────────────────────────────────────────── */
/*  InfoRow — used for read-only profile fields               */
/* ────────────────────────────────────────────────────────── */
const InfoRow: React.FC<{ label: string; value: string }> = ({ label, value }) => (
    <div className="flex flex-col sm:flex-row sm:items-center border-b border-[#F0EBE1] py-3.5 last:border-b-0 gap-1 sm:gap-0">
        <span className="w-full sm:w-36 text-[12px] text-[#8A8A8A] shrink-0">{label}</span>
        <span className="text-[13px] font-semibold text-[#1A1A1A] break-all">{value || "—"}</span>
    </div>
);

/* ────────────────────────────────────────────────────────── */
/*  ProfilePage                                               */
/* ────────────────────────────────────────────────────────── */
const ProfilePage: React.FC = () => {
    const navigate = useNavigate();
    const [searchParams, setSearchParams] = useSearchParams();
    const initialTab = (searchParams.get("tab") as Tab) || "info";
    const returnTo = searchParams.get("returnTo");

    const [user, setUser] = useState<any>(GET_USER_DATA());
    const [reviews, setReviews] = useState<ProductReview[]>([]);
    const [reviewItem, setReviewItem] = useState<OrderItem | null>(null);
    const [editingReview, setEditingReview] = useState<ProductReview | null>(null);
    const [reviewRating, setReviewRating] = useState(0);
    const [reviewTitle, setReviewTitle] = useState("");
    const [reviewText, setReviewText] = useState("");
    const [reviewFile, setReviewFile] = useState<File | null>(null);
    const [reviewError, setReviewError] = useState("");
    const [isSavingReview, setIsSavingReview] = useState(false);
    const [retryingOrderId, setRetryingOrderId] = useState<number | null>(null);
    const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
    const [isLoggingOut, setIsLoggingOut] = useState(false);

    const [locationSearch, setLocationSearch] = useState("");
    const [locationSuggestions, setLocationSuggestions] = useState<{ description: string; place_id: string }[]>([]);
    const [isSearchingLocation, setIsSearchingLocation] = useState(false);
    const locationSearchDebounce = React.useRef<ReturnType<typeof setTimeout> | null>(null);

    const [s, setS] = useState<PageState>({
        activeTab: initialTab,
        isEditingProfile: initialTab === "info" && !(GET_USER_DATA()?.data?.body?.firstName || GET_USER_DATA()?.firstName || "").trim(),
        isSavingProfile: false,
        isProfileLoading: false,
        isVerifyingPan: false,
        profileForm: {
            firstName: "",
            lastName: "",
            email: "",
            alternativeNumber: "",
            whatsappNumber: "",
            mobileNumber: "",
            gender: "",
            panNumber: "",
            panVerified: false,
        },
        profileErrors: {},
        addresses: [],
        isAddressLoading: false,
        isAddingAddress: false,
        editingAddress: null,
        addrForm: {
            flatNo: "", landMark: "", address: "", pinCode: "",
            state: "", type: "Home", latitude: "", longitude: "",
            typeDropdownOpen: false,
        },
        addrErrors: {},
        isFetchingLocation: false,
        locationError: "",
        walletBalance: 0,
        walletTransactions: [],
        isWalletLoading: false,
        orders: [],
        isOrdersLoading: false,
        expandedOrderId: null,
        deliveryTracking: {},
        trackingLoadingOrderId: null,
        trackingErrorOrderId: null,
        toast: null,
        deleteConfirmation: { show: false, addressId: null },
        queries: [],
        isQueriesLoading: false,
        isSubmittingQuery: false,
        queryForm: { query: '', comments: '', file: null },
        queryFormErrors: {},
        queryStatusFilter: 'PENDING',
        showQueryForm: false,
        isUploadingFile: false,
        cancellingQueryId: null,
        cancelQueryConfirmation: { show: false, queryId: null, ticketNumber: '' },
        profileIncompleteModal: false,
    });

    const patch = useCallback(
        (partial: Partial<PageState>) => setS((prev) => ({ ...prev, ...partial })),
        []
    );

    const patchAddrForm = useCallback(
        (partial: Partial<PageState["addrForm"]>) =>
            setS((prev) => ({ ...prev, addrForm: { ...prev.addrForm, ...partial } })),
        []
    );

    const patchProfile = (partial: Partial<PageState["profileForm"]>) =>
        setS((prev) => ({ ...prev, profileForm: { ...prev.profileForm, ...partial } }));

    useEffect(() => {
        const tab = searchParams.get("tab") as Tab;
        if (tab && tab !== s.activeTab) {
            patch({ activeTab: tab, isAddingAddress: false, isEditingProfile: tab === "info" && !s.profileForm.firstName.trim() });
        }
    }, [searchParams, patch, s.activeTab]);

    useEffect(() => {
        if (user) {
            const profile = user.data?.body || user;
            const hasExistingProfile = Boolean(
                (profile.firstName && String(profile.firstName).trim()) ||
                (profile.lastName && String(profile.lastName).trim()) ||
                (profile.email && String(profile.email).trim())
            );
            patch({
                ...(hasExistingProfile ? { isEditingProfile: false } : {}),
                profileForm: {
                    firstName: profile.firstName || "",
                    lastName: profile.lastName || "",
                    email: profile.email || "",
                    alternativeNumber: profile.alternativeNumber || "",
                    whatsappNumber: profile.whatsappNumber || "",
                    mobileNumber: profile.mobileNumber || profile.phone || profile.phoneNumber || "",
                    gender: profile.gender || "",
                    panNumber: profile.panNumber || "",
                    panVerified: profile.panVerified || false,
                },
            });
        }
    }, [user, patch]);

    /* ── fetch helpers ── */
    const fetchProfile = useCallback(async () => {
        const userData = GET_USER_DATA();
        const uid = userData?.data?.userId || userData?.userId;
        if (!uid) return;
        patch({ isProfileLoading: true });
        try {
            const res = await getUserProfile(uid);
            const profile = res.data?.body || res.data;
            if (res.success && profile) {
                const hasExistingProfile = Boolean(
                    (profile.firstName && String(profile.firstName).trim()) ||
                    (profile.lastName && String(profile.lastName).trim()) ||
                    (profile.email && String(profile.email).trim())
                );
                patch({
                    isEditingProfile: !hasExistingProfile,
                    profileForm: {
                        firstName: profile.firstName || "",
                        lastName: profile.lastName || "",
                        email: profile.email || "",
                        alternativeNumber: profile.alternativeNumber || "",
                        whatsappNumber: profile.whatsappNumber || "",
                        mobileNumber: profile.mobileNumber || profile.phone || profile.phoneNumber || "",
                        gender: profile.gender || "",
                        panNumber: profile.panNumber || "",
                        panVerified: profile.panVerified || false,
                    },
                });
                const freshUser = { ...userData, data: { ...userData.data, body: profile } };
                localStorage.setItem("user", JSON.stringify(freshUser));
                setUser(freshUser);
            }
        } catch (err) {
            console.error("Failed to fetch profile:", err);
        } finally {
            patch({ isProfileLoading: false });
        }
    }, [patch]);

    const loadAddresses = useCallback(async () => {
        const userData = GET_USER_DATA();
        const uid = userData?.data?.userId;
        if (!uid) return;
        patch({ isAddressLoading: true });
        try {
            const res = await fetchAddresses(uid);
            const mapped: Address[] = (res.data || res || []).map((a: any) => ({
                id: String(a.id),
                type: a.type || "Home",
                flatNo: a.flatNo || "",
                landMark: a.landMark || "",
                address: a.address || "",
                pinCode: a.pincode || "",
                state: a.state || "",
                longitude: a.longitude || "",
                latitude: a.latitude || "",
            }));
            patch({ addresses: mapped });
        } catch (err) {
            console.error("Failed to fetch addresses:", err);
        } finally {
            patch({ isAddressLoading: false });
        }
    }, [patch]);

    const fetchWalletInfo = useCallback(async () => {
        const userData = GET_USER_DATA();
        const uid = userData?.data?.userId;
        if (!uid) return;
        patch({ isWalletLoading: true });
        try {
            const [balRes, txRes] = await Promise.all([
                fetchWalletBalance(uid),
                fetchWalletTransactions(uid),
            ]);
            patch({
                walletBalance: balRes?.data?.balance || 0,
                walletTransactions: txRes?.data || [],
            });
        } catch (err) {
            console.error("Failed to fetch wallet:", err);
        } finally {
            patch({ isWalletLoading: false });
        }
    }, [patch]);

    const loadOrders = useCallback(async () => {
        const userData = GET_USER_DATA();
        const uid = userData?.data?.userId;
        if (!uid) return;
        patch({ isOrdersLoading: true });
        try {
            const [data, ratingData] = await Promise.all([
                fetchUserOrders(uid),
                fetchMyRatings().catch(() => ({ content: [] as ProductReview[] })),
            ]);
            patch({ orders: data });
            setReviews(ratingData.content || []);
        } catch (err) {
            console.error("Failed to fetch orders:", err);
        } finally {
            patch({ isOrdersLoading: false });
        }
    }, [patch]);

    useEffect(() => {
        if (s.activeTab === "info") fetchProfile();
        if (s.activeTab === "address") loadAddresses();
        if (s.activeTab === "wallet") fetchWalletInfo();
        if (s.activeTab === "orders") loadOrders();
        if (s.activeTab === "support") loadQueries();
    }, [s.activeTab, fetchProfile, loadAddresses, fetchWalletInfo, loadOrders]);

    /* ── actions ── */
    const validatePan = (pan: string): boolean => {
        const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
        return panRegex.test(pan);
    };

    const handleSaveProfile = async () => {
        const userData = GET_USER_DATA();
        const uid = userData?.data?.userId || userData?.userId;
        if (!uid) return;

        const { profileForm } = s;
        const errors: Record<string, string> = {};

        // Required field validations
        if (!profileForm.firstName.trim()) errors.firstName = "First name is required";
        if (!profileForm.lastName.trim()) errors.lastName = "Last name is required";
        if (!profileForm.email.trim()) {
            errors.email = "Email is required";
        } else if (!validateEmail(profileForm.email)) {
            errors.email = "Invalid email format";
        }
        if (!profileForm.alternativeNumber.trim()) {
            errors.alternativeNumber = "Alternative number is required";
        } else if (!validateMobileNumber(profileForm.alternativeNumber)) {
            errors.alternativeNumber = "Invalid mobile number (10 digits, starting with 6-9)";
        } else if (
            profileForm.mobileNumber.trim() &&
            profileForm.alternativeNumber.trim() === profileForm.mobileNumber.trim()
        ) {
            errors.alternativeNumber = "Alternative number must be different from mobile number";
        }
        if (!profileForm.gender) errors.gender = "Gender is required";

        // PAN validation
        if (!profileForm.panNumber.trim()) {
            errors.panNumber = "PAN number is required";
        } else if (!validatePan(profileForm.panNumber.toUpperCase())) {
            errors.panNumber = "Invalid PAN format (e.g., ABCDE1234F)";
        }

        // Optional WhatsApp number validation
        if (profileForm.whatsappNumber.trim() && !validateMobileNumber(profileForm.whatsappNumber)) {
            errors.whatsappNumber = "Invalid mobile number (10 digits, starting with 6-9)";
        }

        if (Object.keys(errors).length) {
            patch({ profileErrors: errors, toast: { message: "Please fix the errors in the form", type: "error" } });
            return;
        }

        patch({ isSavingProfile: true, profileErrors: {} });
        try {
            // Verify PAN if not verified
            if (!profileForm.panVerified) {
                patch({ isVerifyingPan: true });
                try {
                    await verifyPan({
                        pan: profileForm.panNumber.toUpperCase(),
                        firstName: profileForm.firstName.trim(),
                        lastName: profileForm.lastName.trim(),
                    });
                    patch({ isVerifyingPan: false });
                } catch (panErr: any) {
                    patch({
                        isVerifyingPan: false,
                        isSavingProfile: false,
                        profileErrors: { panNumber: panErr.message || "PAN verification failed" },
                        toast: { message: getApiErrorMessage(panErr, "PAN verification failed. Please check your details."), type: "error" }
                    });
                    return;
                }
            }

            await saveUserProfile({
                userId: uid,
                email: profileForm.email,
                alternativeNumber: profileForm.alternativeNumber,
                whatsappNumber: profileForm.whatsappNumber,
                firstName: profileForm.firstName,
                lastName: profileForm.lastName,
                gender: profileForm.gender,
                panNumber: profileForm.panNumber.toUpperCase(),
            });
            const updatedUser = JSON.parse(JSON.stringify(userData));
            const profile = updatedUser.data?.body || updatedUser;
            profile.firstName = profileForm.firstName;
            profile.lastName = profileForm.lastName;
            profile.email = profileForm.email;
            profile.alternativeNumber = profileForm.alternativeNumber;
            profile.whatsappNumber = profileForm.whatsappNumber;
            profile.gender = profileForm.gender;
            profile.panNumber = profileForm.panNumber.toUpperCase();
            profile.panVerified = true;
            localStorage.setItem("user", JSON.stringify(updatedUser));
            setUser(updatedUser);
            patch({ isEditingProfile: false, toast: { message: "Profile updated successfully", type: "success" } });
            if (returnTo === "cart") { setTimeout(() => navigate("/physical-gold/cart"), 800); }
            else if (returnTo === "support") { setTimeout(() => { setSearchParams({ tab: "support" }); patch({ activeTab: "support" }); }, 800); }
            else if (returnTo && returnTo.startsWith("/")) { setTimeout(() => navigate(returnTo), 800); }
        } catch (err) {
            console.error("Failed to save profile:", err);
            const message = getApiErrorMessage(err, "Unable to save profile. Please try again.");
            const profileErrors: Record<string, string> = /whatsapp/i.test(message)
                ? { whatsappNumber: message }
                : {};
            patch({ profileErrors, toast: { message, type: "error" } });
        } finally {
            patch({ isSavingProfile: false, isVerifyingPan: false });
        }
    };

    const handleSaveAddr = async () => {
        const { addrForm, editingAddress } = s;
        const errors: Record<string, string> = {};

        // Required field validations
        if (!addrForm.flatNo.trim()) {
            errors.flatNo = "Flat No / House No is required";
        } else if (addrForm.flatNo.trim().length < 2) {
            errors.flatNo = "Flat No must be at least 2 characters";
        }
        if (!addrForm.landMark.trim()) {
            errors.landMark = "Landmark is required";
        } else if (addrForm.landMark.trim().length < 3) {
            errors.landMark = "Landmark must be at least 3 characters";
        }
        if (!addrForm.address.trim()) {
            errors.address = "Complete address is required";
        } else if (addrForm.address.trim().length < 10) {
            errors.address = "Address must be at least 10 characters";
        }
        const pinErr = getPincodeError(addrForm.pinCode);
        if (pinErr) errors.pinCode = pinErr;
        if (!addrForm.state.trim()) {
            errors.state = "State is required";
        } else if (!/^[a-zA-Z\s]+$/.test(addrForm.state.trim())) {
            errors.state = "State must contain only letters";
        } else if (addrForm.state.trim().length < 3) {
            errors.state = "Please enter a valid state name";
        }

        const duplicateAddress = s.addresses.some((savedAddress) =>
            savedAddress.id !== editingAddress?.id &&
            normaliseAddress(savedAddress) === normaliseAddress(addrForm),
        );
        if (duplicateAddress) {
            errors.address = "This address is already saved";
        }

        if (Object.keys(errors).length) {
            patch({ addrErrors: errors, toast: { message: "Please fix the errors in the form", type: "error" } });
            return;
        }

        const userData = GET_USER_DATA();
        const uid = userData?.data?.userId;
        if (!uid) return;

        // Always re-geocode on edit; geocode if lat/lng missing on new address
        let lat = addrForm.latitude;
        let lng = addrForm.longitude;
        const shouldGeocode = editingAddress || !lat || !lng;
        if (shouldGeocode) {
            const query = [addrForm.flatNo, addrForm.landMark, addrForm.address, addrForm.pinCode, addrForm.state].filter(Boolean).join(", ");
            try {
                const res = await fetch(
                    `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(query)}&key=${GOOGLE_API_KEY}`
                );
                const data = await res.json();
                if (data.status === "OK" && data.results?.[0]?.geometry?.location) {
                    lat = String(data.results[0].geometry.location.lat);
                    lng = String(data.results[0].geometry.location.lng);
                    patchAddrForm({ latitude: lat, longitude: lng });
                }
            } catch (err) {
                console.error("Geocoding failed on save:", err);
            }
        }

        const payload = {
            id: editingAddress?.id,
            userId: uid,
            flatNo: addrForm.flatNo,
            address: addrForm.address,
            state: addrForm.state,
            pinCode: addrForm.pinCode,
            landMark: addrForm.landMark,
            longitude: lng || "",
            latitude: lat || "",
        };

        patch({ isAddressLoading: true, addrErrors: {} });
        try {
            if (editingAddress) await updateAddress(payload);
            else await addAddress(payload);
            await loadAddresses();
            patch({
                isAddingAddress: false, editingAddress: null,
                addrForm: { flatNo: "", landMark: "", address: "", pinCode: "", state: "", type: "Home", latitude: "", longitude: "", typeDropdownOpen: false },
                toast: { message: editingAddress ? "Address updated successfully" : "Address added successfully", type: "success" },
            });
        } catch (err) {
            console.error("Failed to save address:", err);
            const message = getApiErrorMessage(err, "Failed to save address. Please try again.");
            patch({
                addrErrors: /pin\s*code|pincode|postal/i.test(message) ? { pinCode: message } : {},
                toast: { message, type: "error" },
            });
        } finally {
            patch({ isAddressLoading: false });
        }
    };

    const handleEditAddress = (addr: Address) => {
        patch({ editingAddress: addr, isAddingAddress: true, addrErrors: {} });
        patchAddrForm({
            flatNo: addr.flatNo, landMark: addr.landMark, address: addr.address,
            pinCode: addr.pinCode, state: addr.state, type: addr.type,
            latitude: addr.latitude, longitude: addr.longitude, typeDropdownOpen: false,
        });
    };

    const GOOGLE_API_KEY = "AIzaSyAM29otTWBIAefQe6mb7f617BbnXTHtN0M";

    const geocodeAddressFields = async () => {
        const { flatNo, landMark, address, pinCode, state } = s.addrForm;
        if (!flatNo.trim() || !address.trim() || !pinCode.trim() || !state.trim()) return;
        const query = [flatNo, landMark, address, pinCode, state].filter(Boolean).join(", ");
        try {
            const res = await fetch(
                `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(query)}&key=${GOOGLE_API_KEY}`
            );
            const data = await res.json();
            if (data.status === "OK" && data.results?.[0]?.geometry?.location) {
                const { lat, lng } = data.results[0].geometry.location;
                patchAddrForm({ latitude: String(lat), longitude: String(lng) });
                patch({ addrErrors: removeErrorKey(s.addrErrors, "latitude") });
            }
        } catch (err) {
            console.error("Geocoding failed:", err);
        }
    };

    /* ── Parse Google geocode result into address fields ── */
    const parseGeocodeResult = (result: any) => {
        const components: any[] = result.address_components || [];
        const getAll = (type: string) =>
            components.filter((c) => c.types.includes(type)).map((c) => c.long_name);
        const get = (type: string) => getAll(type)[0] || "";

        const premises = getAll("premise");
        const streetNumber = get("street_number");
        const route = get("route");
        const neighborhood = get("neighborhood");
        const sublocality3 = get("sublocality_level_3");
        const sublocality2 = get("sublocality_level_2");
        const sublocality1 = get("sublocality_level_1");
        const locality = get("locality");
        const district = get("administrative_area_level_3") || get("administrative_area_level_2");
        const state = get("administrative_area_level_1");
        const pinCode = get("postal_code");

        // flatNo: all premise values joined (e.g. "Indu Fortune Fields Villa-251, 251") or street number
        const flatNo = premises.length ? premises.join(", ") : ([streetNumber].filter(Boolean).join(", ") || sublocality2 || "");
        // landmark: route or neighborhood/sublocality
        const landMark = route || neighborhood || sublocality3 || sublocality1 || "";
        // address: strip country + state + pincode from formatted_address for a clean full address
        const formatted = (result.formatted_address || "");
        const address = formatted
            .replace(/,?\s*India$/, "")
            .replace(/,?\s*[A-Z]{2}\s+\d{6}/, "")
            .replace(/,?\s*Telangana/, "")
            .replace(/,?\s*[A-Za-z\s]+\s+\d{6}/, "")
            .trim()
            .replace(/,$/, "")
            .trim();

        return { flatNo, landMark, address, pinCode, state, locality: locality || district };
    };

    const fetchCurrentLocation = () => {
        if (!navigator.geolocation) {
            patch({
                isFetchingLocation: false,
                toast: { message: "Geolocation is not supported by your browser", type: "error" }
            });
            return;
        }

        patch({ isFetchingLocation: true, locationError: "" });
        let completed = false;
        const finish = (updates: Partial<PageState>) => {
            if (completed) return;
            completed = true;
            window.clearTimeout(safetyTimer);
            patch({ ...updates, isFetchingLocation: false });
        };
        const safetyTimer = window.setTimeout(() => {
            finish({
                locationError: "Location request timed out",
                toast: { message: "Location request timed out. Check your device location settings and try again.", type: "error" }
            });
        }, 16000);

        navigator.geolocation.getCurrentPosition(
            async (position) => {
                if (completed) return;
                const lat = position.coords.latitude.toString();
                const lng = position.coords.longitude.toString();
                patchAddrForm({ latitude: lat, longitude: lng });

                // Reverse geocode to fill address fields
                try {
                    const res = await fetch(
                        `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${GOOGLE_API_KEY}`
                    );
                    const data = await res.json();
                    if (data.status === "OK" && data.results?.[0]) {
                        const parsed = parseGeocodeResult(data.results[0]);
                        patchAddrForm({
                            latitude: lat,
                            longitude: lng,
                            ...(parsed.flatNo && { flatNo: parsed.flatNo }),
                            ...(parsed.landMark && { landMark: parsed.landMark }),
                            ...(parsed.address && { address: parsed.address }),
                            ...(parsed.pinCode && { pinCode: parsed.pinCode }),
                            ...(parsed.state && { state: parsed.state }),
                        });
                        const nextErrors = { ...s.addrErrors };
                        delete nextErrors.latitude;
                        finish({
                            locationError: "",
                            addrErrors: nextErrors,
                            toast: { message: "Location detected — please review and confirm the filled details", type: "success" }
                        });
                    } else {
                        finish({
                            locationError: "",
                            addrErrors: { ...s.addrErrors },
                            toast: { message: "Location captured. Address details could not be auto-filled — please enter them manually.", type: "success" }
                        });
                    }
                } catch {
                    finish({
                        locationError: "",
                        toast: { message: "Location captured. Could not fetch address details — please fill them manually.", type: "success" }
                    });
                }
            },
            (error) => {
                console.error("Geolocation error:", error);
                const messages: Record<number, string> = {
                    1: "Location permission was denied. Allow location access in your browser settings.",
                    2: "Your current location is unavailable. Check your device location settings.",
                    3: "Location request timed out. Move to an area with a better GPS signal and try again.",
                };
                const message = messages[error.code] || "Failed to get your current location. Please try again.";
                finish({
                    locationError: message,
                    toast: { message, type: "error" }
                });
            },
            {
                enableHighAccuracy: true,
                timeout: 15000,
                maximumAge: 30000,
            }
        );
    };

    /* ── Pincode lookup: auto-fill state only on valid 6-digit pin ── */
    const lookupPincode = async (pin: string) => {
        if (!validatePincode(pin)) return;
        try {
            const res = await fetch(
                `https://maps.googleapis.com/maps/api/geocode/json?address=${pin},India&key=${GOOGLE_API_KEY}`
            );
            const data = await res.json();
            if (data.status === "OK" && data.results?.[0]) {
                const parsed = parseGeocodeResult(data.results[0]);
                if (parsed.state) {
                    patchAddrForm({ state: parsed.state });
                    patch({ addrErrors: removeErrorKey(s.addrErrors, "state") });
                }
            }
        } catch {
            // silent — pincode lookup is best-effort
        }
    };

    /* ── Location text search via Places Autocomplete ── */
    const searchLocationByText = (query: string) => {
        setLocationSearch(query);
        if (locationSearchDebounce.current) clearTimeout(locationSearchDebounce.current);
        if (!query.trim() || query.length < 3) { setLocationSuggestions([]); return; }
        locationSearchDebounce.current = setTimeout(async () => {
            setIsSearchingLocation(true);
            try {
                const res = await fetch(
                    `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(query)}&components=country:in&key=${GOOGLE_API_KEY}`
                );
                const data = await res.json();
                setLocationSuggestions(data.predictions?.slice(0, 5) || []);
            } catch { setLocationSuggestions([]); }
            finally { setIsSearchingLocation(false); }
        }, 350);
    };

    const selectLocationSuggestion = async (placeId: string, description: string) => {
        setLocationSearch(description);
        setLocationSuggestions([]);
        setIsSearchingLocation(true);
        try {
            const res = await fetch(
                `https://maps.googleapis.com/maps/api/geocode/json?place_id=${placeId}&key=${GOOGLE_API_KEY}`
            );
            const data = await res.json();
            if (data.status === "OK" && data.results?.[0]) {
                const parsed = parseGeocodeResult(data.results[0]);
                const { lat, lng } = data.results[0].geometry.location;
                patchAddrForm({
                    latitude: String(lat),
                    longitude: String(lng),
                    ...(parsed.flatNo && { flatNo: parsed.flatNo }),
                    ...(parsed.landMark && { landMark: parsed.landMark }),
                    ...(parsed.address && { address: parsed.address }),
                    ...(parsed.pinCode && { pinCode: parsed.pinCode }),
                    ...(parsed.state && { state: parsed.state }),
                });
                // clear errors for filled fields
                setS(prev => ({
                    ...prev,
                    addrErrors: Object.fromEntries(
                        Object.entries(prev.addrErrors).filter(([k]) =>
                            !['flatNo','landMark','address','pinCode','state','latitude'].includes(k)
                        )
                    )
                }));
                setLocationSearch("");
                patch({ toast: { message: "Address filled from search — please review and confirm", type: "success" } });
            }
        } catch { patch({ toast: { message: "Could not fetch address details. Please try again.", type: "error" } }); }
        finally { setIsSearchingLocation(false); }
    };

    const cancelAddrForm = () => {
        setLocationSearch("");
        setLocationSuggestions([]);
        patch({
            isAddingAddress: false, editingAddress: null, addrErrors: {},
            isFetchingLocation: false, locationError: "",
            addrForm: { flatNo: "", landMark: "", address: "", pinCode: "", state: "", type: "Home", latitude: "", longitude: "", typeDropdownOpen: false },
        });
    };

    const handleDeleteAddress = async (addressId: string) => {
        const userData = GET_USER_DATA();
        const uid = userData?.data?.userId;
        if (!uid) return;

        patch({ isAddressLoading: true, deleteConfirmation: { show: false, addressId: null } });
        try {
            await deleteAddress(uid, addressId);
            await loadAddresses();
            patch({ toast: { message: "Address deleted successfully", type: "success" } });
        } catch (err) {
            console.error("Failed to delete address:", err);
            patch({ toast: { message: getApiErrorMessage(err, "Failed to delete address. Please try again."), type: "error" } });
        } finally {
            patch({ isAddressLoading: false });
        }
    };

    const loadDeliveryTracking = async (orderId: number) => {
        if (s.deliveryTracking[orderId] || s.trackingLoadingOrderId === orderId) return;
        const userData = GET_USER_DATA();
        const userId = userData?.data?.userId || userData?.userId;
        if (!userId) return;

        patch({ trackingLoadingOrderId: orderId, trackingErrorOrderId: null });
        try {
            const tracking = await fetchOrderDeliveryTracking(orderId, userId);
            patch({ deliveryTracking: { ...s.deliveryTracking, [orderId]: tracking } });
        } catch (error) {
            console.error("Failed to fetch delivery tracking:", error);
            patch({ trackingErrorOrderId: orderId });
        } finally {
            patch({ trackingLoadingOrderId: null });
        }
    };

    const toggleOrderExpand = (orderId: number) => {
        const isClosing = s.expandedOrderId === orderId;
        patch({ expandedOrderId: isClosing ? null : orderId });
        const currentOrder = s.orders.find((o) => o.orderId === orderId);
        if (!isClosing && currentOrder?.paymentStatus !== 'PENDING') {
            loadDeliveryTracking(orderId);
        }
    };

    const handleRetryPayment = async (order: Order) => {
        setRetryingOrderId(order.orderId);
        try {
            const res = await retryOrderPayment(order.orderId);
            if (res?.success && res?.data?.paymentSessionId) {
                const cashfree = await load({ mode: "production" });
                const txnId = res.data.transactionId;
                const paymentSessionId = res.data.paymentSessionId;
                cashfree.checkout({
                    paymentSessionId,
                    redirectTarget: "_self",
                    returnUrl: `${window.location.origin}/physical-gold/payment-status?order_id=${txnId}&internal_id=${order.orderId}&order_number=${order.orderNumber}`,
                });
            } else {
                patch({
                    toast: {
                        message: res?.message || "Failed to generate payment session",
                        type: "error",
                    },
                });
            }
        } catch (err: any) {
            console.error("Payment retry failed:", err);
            patch({
                toast: {
                    message: getApiErrorMessage(err, "Payment retry failed. Please try again."),
                    type: "error",
                },
            });
        } finally {
            setRetryingOrderId(null);
        }
    };

    const openProductReview = async (item: OrderItem) => {
        const existing = reviews.find((review) => review.productId === item.productId);
        setReviewItem(item);
        setEditingReview(existing || null);
        setReviewRating(existing?.rating || 0);
        setReviewTitle(existing?.title || "");
        setReviewText(existing?.reviewText || "");
        setReviewFile(null);
        setReviewError("");
        if (existing) {
            try {
                const [freshReview, media] = await Promise.all([
                    fetchRating(existing.id),
                    fetchRatingMedia(existing.id).catch(() => existing.media || []),
                ]);
                const completeReview = { ...freshReview, media };
                setEditingReview(completeReview);
                setReviewRating(completeReview.rating);
                setReviewTitle(completeReview.title || "");
                setReviewText(completeReview.reviewText || "");
            } catch {
                setReviewError("We could not refresh this review, but you can still edit the saved version below.");
            }
        }
    };

    const selectReviewFile = (file: File | null) => {
        setReviewError("");
        if (!file) { setReviewFile(null); return; }
        if (!REVIEW_MEDIA_TYPES.includes(file.type)) {
            setReviewFile(null); setReviewError("Use a JPG, PNG, WebP, MP4, or WebM file."); return;
        }
        const maxBytes = file.type.startsWith("video/") ? VIDEO_MAX_BYTES : IMAGE_MAX_BYTES;
        if (file.size > maxBytes) {
            setReviewFile(null); setReviewError(file.type.startsWith("video/") ? "Video must be 50 MB or smaller." : "Image must be 10 MB or smaller."); return;
        }
        setReviewFile(file);
    };

    const closeProductReview = () => {
        if (isSavingReview) return;
        setReviewItem(null); setEditingReview(null); setReviewError("");
    };

    const saveProductReview = async () => {
        if (!reviewItem || reviewRating < 1) { setReviewError("Please select a star rating."); return; }
        if (reviewTitle.trim().length < REVIEW_TITLE_MIN) { setReviewError(`Review title must be at least ${REVIEW_TITLE_MIN} characters.`); return; }
        if (reviewText.trim().length < REVIEW_TEXT_MIN) { setReviewError(`Review must be at least ${REVIEW_TEXT_MIN} characters.`); return; }
        const orderItemId = reviewItem.orderItemId ?? reviewItem.id;
        if (!editingReview && !orderItemId) { setReviewError("Order item information is unavailable. Refresh My Orders and try again."); return; }
        try {
            setIsSavingReview(true); setReviewError("");
            const saved = editingReview
                ? await updateRating(editingReview.id, { rating: reviewRating, title: reviewTitle.trim(), reviewText: reviewText.trim() })
                : await createRating({ orderItemId: orderItemId!, rating: reviewRating, title: reviewTitle.trim(), reviewText: reviewText.trim() });
            let mediaUploadFailed = false;
            if (reviewFile) {
                try { await uploadRatingMedia(saved.id, reviewFile, saved.media?.length || 0); }
                catch { mediaUploadFailed = true; }
            }
            const refreshed = await fetchMyRatings().catch(() => null);
            setReviews(refreshed?.content || [saved, ...reviews.filter((review) => review.id !== saved.id)]);
            setReviewItem(null); setEditingReview(null);
            patch({ toast: { message: mediaUploadFailed ? "Review saved, but the media upload failed. You can edit the review and try again." : editingReview ? "Review updated successfully" : "Thank you! Your review was submitted for moderation.", type: mediaUploadFailed ? "error" : "success" } });
        } catch (error) {
            const message = error instanceof Error ? error.message : "Unable to save your review.";
            setReviewError(message.includes("has not been delivered") ? "You can review this product after the order has been delivered." : message);
        } finally { setIsSavingReview(false); }
    };

    const loadQueries = useCallback(async (statusOverride?: string) => {
        const userData = GET_USER_DATA();
        const uid = userData?.data?.userId;
        if (!uid) return;
        patch({ isQueriesLoading: true });
        try {
            const res = await getAllQueries({
                userId: uid,
                queryStatus: statusOverride ?? s.queryStatusFilter,
                page: 0,
                size: 20,
            });
            const queries = Array.isArray(res?.data)
                ? res.data
                : res?.data?.content || res?.content || [];
            patch({ queries });
        } catch (err) {
            console.error('Failed to fetch queries:', err);
        } finally {
            patch({ isQueriesLoading: false });
        }
    }, [patch, s.queryStatusFilter]);

    const handleSubmitQuery = async () => {
        const userData = GET_USER_DATA();
        const uid = userData?.data?.userId;
        if (!uid) return;

        const errors: Record<string, string> = {};
        const query = s.queryForm.query.trim();
        if (!s.profileForm.email?.trim()) errors.email = 'Email is required.';
        else if (!validateEmail(s.profileForm.email)) errors.email = 'Enter a valid email address.';
        if (!s.profileForm.mobileNumber?.trim()) errors.mobileNumber = 'Mobile number is required.';
        else if (!validateMobileNumber(s.profileForm.mobileNumber)) errors.mobileNumber = 'Enter a valid 10-digit mobile number.';
        if (!query) errors.query = 'Please describe your issue or question.';
        else if (query.length < 10) errors.query = 'Query must contain at least 10 characters.';

        if (Object.keys(errors).length > 0) {
            patch({ queryFormErrors: errors, toast: { message: 'Please correct the highlighted fields.', type: 'error' } });
            return;
        }

        patch({ isSubmittingQuery: true, queryFormErrors: {} });
        try {
            const result = await writeQuery({
                userId: uid,
                query,
                email: s.profileForm.email,
            });

            let attachmentUploaded = true;
            if (s.queryForm.file) {
                patch({ isUploadingFile: true });
                try {
                    // The upload API calls this queryId, but it expects writeQuery's ticketId.
                    await uploadQueryScreenshot(uid, result.ticketId, s.queryForm.file);
                } catch (uploadErr) {
                    console.error('File upload failed:', uploadErr);
                    attachmentUploaded = false;
                } finally {
                    patch({ isUploadingFile: false });
                }
            }

            patch({
                queryForm: { query: '', comments: '', file: null },
                queryFormErrors: {},
                showQueryForm: false,
                queryStatusFilter: 'PENDING',
                toast: attachmentUploaded
                    ? { message: s.queryForm.file ? `Query ${result.randomTicketId || `#${result.ticketId}`} and attachment submitted successfully!` : `Query ${result.randomTicketId || `#${result.ticketId}`} submitted successfully!`, type: 'success' }
                    : { message: 'Query submitted, but the attachment could not be uploaded. Please keep your ticket number and try again later.', type: 'error' },
            });
            // Newly raised queries are pending, so refresh that list explicitly.
            await loadQueries('PENDING');
        } catch (err) {
            console.error('Failed to submit query:', err);
            patch({ toast: { message: getApiErrorMessage(err, 'Failed to submit query. Please try again.'), type: 'error' } });
        } finally {
            patch({ isSubmittingQuery: false });
        }
    };

    const handleCancelQuery = async (queryId: number) => {
        const userData = GET_USER_DATA();
        const uid = userData?.data?.userId;
        if (!uid) return;

        patch({ cancellingQueryId: queryId });
        try {
            await cancelQuery(queryId, uid);
            patch({
                toast: { message: 'Query cancelled successfully.', type: 'success' },
                cancelQueryConfirmation: { show: false, queryId: null, ticketNumber: '' },
            });
            await loadQueries();
        } catch (err) {
            console.error('Failed to cancel query:', err);
            patch({ toast: { message: getApiErrorMessage(err, 'Failed to cancel query. Please try again.'), type: 'error' } });
        } finally {
            patch({ cancellingQueryId: null });
        }
    };

    const handleLogout = async () => {
        setIsLoggingOut(true);
        try {
            const stored = localStorage.getItem("user");
            if (stored) {
                const ud = JSON.parse(stored);
                if (ud.data?.accessToken) {
                    await logout(ud.data.accessToken);
                }
            }
        } catch (e) {
            console.error("Logout failed:", e);
        } finally {
            TokenManager.getInstance().clearTokens();
            setShowLogoutConfirm(false);
            setIsLoggingOut(false);
            navigate("/login", { replace: true });
        }
    };

    const displayName = user
        ? `${user.data?.body?.firstName || user.firstName || ""} ${user.data?.body?.lastName || user.lastName || ""}`.trim() || "My Account"
        : "My Account";

    const displayEmail = user?.data?.body?.email || user?.email || "";
    const displayPhone = user?.data?.body?.mobileNumber || user?.phone || "";

    const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
        { id: "info", label: "Profile", icon: User },
        { id: "orders", label: "My Orders", icon: Package },
        { id: "address", label: "Address", icon: MapPin },
        // { id: "wallet", label: "Wallet", icon: Wallet },
        { id: "support", label: "Write to Us", icon: MessageSquare },
    ];

    return (
        <div className="min-h-screen bg-[#F5F2EE] text-[#1A1A1A]">
            <PhysicalGoldHeader />

            {/* Toast */}
            {s.toast && (
                <Toast
                    message={s.toast.message}
                    type={s.toast.type}
                    onClose={() => patch({ toast: null })}
                />
            )}

            <main className="pt-28 sm:pt-36 pb-12 sm:pb-20 max-w-5xl mx-auto px-3 sm:px-6">

                {/* Back */}
                <button
                    type="button"
                    onClick={() => navigate("/physical-gold")}
                    className="mb-2 mt-2 inline-flex items-center gap-1.5 text-[13px] font-medium text-[#8A8A8A] hover:text-[#8B6914] transition"
                >
                    <ArrowLeft className="h-3.5 w-3.5" />
                    Back to Shopping
                </button>

                {/* Profile Header Card */}
                <div className="bg-white border border-[#E8E0D5] rounded-xl px-4 sm:px-6 py-4 flex flex-row items-center justify-between gap-3 mb-1 shadow-sm">
                    <div className="flex items-center gap-3 sm:gap-4 min-w-0">
                        <div className="h-11 w-11 rounded-full bg-[#F5EDD6] flex items-center justify-center text-[#8B6914] shrink-0">
                            <User className="h-5 w-5" strokeWidth={1.8} />
                        </div>
                        <div className="min-w-0 flex-1">
                            <h1 className="text-[15px] font-semibold text-[#1A1A1A] leading-tight truncate">{displayName}</h1>
                            <p className="text-[11px] text-[#8A8A8A] mt-0.5 truncate">
                                {displayEmail}{displayPhone ? ` · ${displayPhone}` : ""}
                            </p>
                        </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                        {s.activeTab === 'info' && !s.isEditingProfile && (
                            <button
                                type="button"
                                onClick={() => {
                                    setSearchParams({ tab: "info" });
                                    patch({ activeTab: "info", isEditingProfile: true });
                                }}
                                className="cursor-pointer inline-flex items-center justify-center gap-1.5 border border-[#E8E0D5] bg-white rounded-lg px-3 sm:px-3.5 py-1.5 text-[12px] font-medium text-[#1A1A1A] hover:bg-[#F5F2EE] hover:border-[#D1C7BB] transition shadow-2xs active:scale-95"
                            >
                                <Pencil className="h-3 w-3 text-[#8B6914]" />
                                <span>Edit Profile</span>
                            </button>
                        )}
                        <button
                            type="button"
                            onClick={() => setShowLogoutConfirm(true)}
                            className="cursor-pointer inline-flex items-center justify-center gap-1.5 border border-rose-200 bg-rose-50/70 rounded-lg px-3 sm:px-3.5 py-1.5 text-[12px] font-medium text-rose-600 hover:bg-rose-100 hover:border-rose-300 transition shrink-0 shadow-2xs active:scale-95"
                        >
                            <LogOut className="h-3.5 w-3.5 text-rose-500" />
                            <span>Log Out</span>
                        </button>
                    </div>
                </div>

                {/* Tabs */}
                <div className="bg-white border border-[#E8E0D5] border-t-0 rounded-b-xl shadow-sm mb-6">
                    <div className="flex border-b border-[#F0EBE1] overflow-x-auto whitespace-nowrap [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
                        {tabs.map(({ id, label, icon: Icon }) => {
                            const isActive = s.activeTab === id;
                            return (
                                <button
                                    key={id}
                                    onClick={() => {
                                        if (id === "support") {
                                            const p = s.profileForm;
                                            const isProfileFilled = p.firstName.trim() && p.lastName.trim() && p.email.trim() && p.mobileNumber.trim();
                                            if (!isProfileFilled) {
                                                patch({ profileIncompleteModal: true });
                                                return;
                                            }
                                        }
                                        setSearchParams({ tab: id });
                                        patch({ activeTab: id, isAddingAddress: false, isEditingProfile: id === "info" && !s.profileForm.firstName.trim() });
                                    }}
                                    className={`flex items-center gap-1.5 px-4 py-3.5 text-[13px] font-medium border-b-2 transition-all shrink-0 ${isActive ? "border-[#8B6914] text-[#8B6914]" : "border-transparent text-[#8A8A8A] hover:text-[#1A1A1A]"}`}
                                >
                                    <Icon className="h-3.5 w-3.5" strokeWidth={isActive ? 2.5 : 1.8} />
                                    {label}
                                </button>
                            );
                        })}
                    </div>

                    {/* ── PROFILE TAB ── */}
                    {s.activeTab === "info" && (
                        <div className="p-4 sm:p-6">
                            {s.isProfileLoading ? (
                                <div className="flex items-center justify-center py-16 gap-2 text-[#8A8A8A]">
                                    <Loader2 className="h-5 w-5 animate-spin" />
                                    <span className="text-[12px]">Loading...</span>
                                </div>
                            ) : s.isEditingProfile ? (
                                <div className="space-y-5 max-w-2xl">
                                    <h3 className="text-[18px] font-semibold text-[#1A1A1A] mb-4">Personal Information</h3>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                        <div>
                                            <label className={labelCls}>First Name<span className="text-rose-500 ml-1">*</span></label>
                                            <input
                                                value={s.profileForm.firstName}
                                                onChange={(e) => {
                                                    patchProfile({ firstName: e.target.value });
                                                    if (s.profileErrors.firstName && e.target.value.trim()) {
                                                        patch({ profileErrors: removeErrorKey(s.profileErrors, "firstName") });
                                                    }
                                                }}
                                                className={`${inputCls} ${s.profileErrors.firstName ? "border-rose-400 focus:border-rose-400 focus:ring-rose-400/10" : ""}`}
                                            />
                                            {s.profileErrors.firstName && <p className="text-[11px] text-rose-500 mt-1">{s.profileErrors.firstName}</p>}
                                        </div>
                                        <div>
                                            <label className={labelCls}>Last Name<span className="text-rose-500 ml-1">*</span></label>
                                            <input
                                                value={s.profileForm.lastName}
                                                onChange={(e) => {
                                                    patchProfile({ lastName: e.target.value });
                                                    if (s.profileErrors.lastName && e.target.value.trim()) {
                                                        patch({ profileErrors: removeErrorKey(s.profileErrors, "lastName") });
                                                    }
                                                }}
                                                className={`${inputCls} ${s.profileErrors.lastName ? "border-rose-400 focus:border-rose-400 focus:ring-rose-400/10" : ""}`}
                                            />
                                            {s.profileErrors.lastName && <p className="text-[11px] text-rose-500 mt-1">{s.profileErrors.lastName}</p>}
                                        </div>
                                    </div>
                                    <div>
                                        <label className={labelCls}>Email<span className="text-rose-500 ml-1">*</span></label>
                                        <input
                                            type="email"
                                            value={s.profileForm.email}
                                            onChange={(e) => {
                                                patchProfile({ email: e.target.value });
                                                if (s.profileErrors.email) {
                                                    if (e.target.value.trim() && validateEmail(e.target.value)) {
                                                        patch({ profileErrors: removeErrorKey(s.profileErrors, "email") });
                                                    }
                                                }
                                            }}
                                            className={`${inputCls} ${s.profileErrors.email ? "border-rose-400 focus:border-rose-400 focus:ring-rose-400/10" : ""}`}
                                        />
                                        {s.profileErrors.email && <p className="text-[11px] text-rose-500 mt-1">{s.profileErrors.email}</p>}
                                    </div>
                                    <Dropdown
                                        label="Gender"
                                        value={s.profileForm.gender}
                                        options={[
                                            { value: "male", label: "Male" },
                                            { value: "female", label: "Female" },
                                        ]}
                                        onChange={(value) => {
                                            patchProfile({ gender: value });
                                            if (s.profileErrors.gender && value) {
                                                patch({ profileErrors: removeErrorKey(s.profileErrors, "gender") });
                                            }
                                        }}
                                        required
                                        error={s.profileErrors.gender}
                                    />
                                    <div>
                                        <label className={labelCls}>Mobile Number</label>
                                        <input
                                            type="tel"
                                            value={s.profileForm.mobileNumber}
                                            disabled
                                            className={`${inputCls} bg-[#F5F2EE] cursor-not-allowed opacity-60`}
                                        />
                                        <p className="text-[11px] text-[#8A8A8A] mt-1">Mobile number cannot be changed. Contact support if needed.</p>
                                    </div>
                                    <div>
                                        <label className={labelCls}>Alternative Number<span className="text-rose-500 ml-1">*</span></label>
                                        <input
                                            type="tel"
                                            value={s.profileForm.alternativeNumber}
                                            onChange={(e) => {
                                                const formatted = formatMobileNumber(e.target.value);
                                                if (formatted.length <= 10) {
                                                    patchProfile({ alternativeNumber: formatted });
                                                    if (s.profileErrors.alternativeNumber) {
                                                        if (formatted.trim() && validateMobileNumber(formatted)) {
                                                            patch({ profileErrors: removeErrorKey(s.profileErrors, "alternativeNumber") });
                                                        }
                                                    }
                                                }
                                            }}
                                            placeholder="10-digit mobile number"
                                            className={`${inputCls} ${s.profileErrors.alternativeNumber ? "border-rose-400 focus:border-rose-400 focus:ring-rose-400/10" : ""}`}
                                        />
                                        {s.profileErrors.alternativeNumber && <p className="text-[11px] text-rose-500 mt-1">{s.profileErrors.alternativeNumber}</p>}
                                    </div>
                                    <div>
                                        <label className={labelCls}>WhatsApp Number<span className="text-rose-500">*</span></label>
                                        <input
                                            type="tel"
                                            value={s.profileForm.whatsappNumber}
                                            onChange={(e) => {
                                                const formatted = formatMobileNumber(e.target.value);
                                                if (formatted.length <= 10) {
                                                    patchProfile({ whatsappNumber: formatted });
                                                    if (s.profileErrors.whatsappNumber) {
                                                        if (!formatted.trim() || validateMobileNumber(formatted)) {
                                                            patch({ profileErrors: removeErrorKey(s.profileErrors, "whatsappNumber") });
                                                        }
                                                    }
                                                }
                                            }}
                                            placeholder="10-digit mobile number"
                                            className={`${inputCls} ${s.profileErrors.whatsappNumber ? "border-rose-400 focus:border-rose-400 focus:ring-rose-400/10" : ""}`}
                                        />
                                        {s.profileErrors.whatsappNumber && <p className="text-[11px] text-rose-500 mt-1">{s.profileErrors.whatsappNumber}</p>}
                                    </div>
                                    <div>
                                        <label className={labelCls}>
                                            PAN Number<span className="text-rose-500 ml-1">*</span>
                                            {s.profileForm.panVerified && (
                                                <span className="ml-2 inline-flex items-center gap-1 text-emerald-600 text-[10px] font-semibold">
                                                    <CheckCircle2 className="h-3 w-3" /> Verified
                                                </span>
                                            )}
                                        </label>
                                        <input
                                            type="text"
                                            value={s.profileForm.panNumber}
                                            onChange={(e) => {
                                                const formatted = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
                                                if (formatted.length <= 10) {
                                                    patchProfile({ panNumber: formatted });
                                                    if (s.profileErrors.panNumber && formatted.trim()) {
                                                        patch({ profileErrors: removeErrorKey(s.profileErrors, "panNumber") });
                                                    }
                                                }
                                            }}
                                            placeholder="ABCDE1234F"
                                            maxLength={10}
                                            disabled={s.profileForm.panVerified}
                                            className={`${inputCls} ${s.profileForm.panVerified ? "bg-[#F5F2EE] cursor-not-allowed opacity-60" : ""} ${s.profileErrors.panNumber ? "border-rose-400 focus:border-rose-400 focus:ring-rose-400/10" : ""}`}
                                        />
                                        {s.profileErrors.panNumber && <p className="text-[11px] text-rose-500 mt-1">{s.profileErrors.panNumber}</p>}
                                        {s.profileForm.panVerified && <p className="text-[11px] text-[#8A8A8A] mt-1">PAN is verified and cannot be changed.</p>}
                                    </div>

                                    <div className="flex gap-3 pt-2">
                                        <button onClick={() => patch({ isEditingProfile: false, profileErrors: {} })} className="px-5 py-2 rounded-lg border border-[#E8E0D5] text-[12px] font-medium text-[#8A8A8A] hover:bg-[#F5F2EE] transition">Cancel</button>
                                        <button onClick={handleSaveProfile} disabled={s.isSavingProfile || s.isVerifyingPan} className="inline-flex items-center gap-2 px-5 py-2 rounded-lg bg-[#8B6914] text-white text-[12px] font-medium hover:bg-[#7A5C10] transition disabled:opacity-60">
                                            {s.isVerifyingPan ? (
                                                <>
                                                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                                    Verifying PAN...
                                                </>
                                            ) : s.isSavingProfile ? (
                                                <>
                                                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                                    Saving...
                                                </>
                                            ) : (
                                                <>
                                                    <CheckCircle2 className="h-3.5 w-3.5" />
                                                    Save Changes
                                                </>
                                            )}
                                        </button>
                                    </div>
                                </div>
                            ) : (
                                <div className="max-w-2xl">
                                    <h3 className="text-[18px] font-semibold text-[#1A1A1A] mb-4">Personal Information</h3>
                                    <div className="divide-y divide-[#F0EBE1]">
                                        <InfoRow label="Full Name" value={`${s.profileForm.firstName} ${s.profileForm.lastName}`.trim()} />
                                        <InfoRow label="Email" value={s.profileForm.email} />
                                        <InfoRow label="Gender" value={s.profileForm.gender ? s.profileForm.gender.charAt(0).toUpperCase() + s.profileForm.gender.slice(1) : "—"} />
                                        <InfoRow label="Mobile Number" value={s.profileForm.mobileNumber} />
                                        <InfoRow label="Alt. Number" value={s.profileForm.alternativeNumber} />
                                        <InfoRow label="WhatsApp" value={s.profileForm.whatsappNumber} />
                                        <div className="flex flex-col sm:flex-row sm:items-center border-b border-[#F0EBE1] py-3.5 last:border-b-0 gap-1 sm:gap-0">
                                            <span className="w-full sm:w-36 text-[12px] text-[#8A8A8A] shrink-0">PAN Number</span>
                                            <div className="flex items-center gap-2 min-w-0">
                                                <span className="text-[13px] font-semibold text-[#1A1A1A] break-all">
                                                    {s.profileForm.panNumber ? (
                                                        s.profileForm.panVerified ?
                                                            `${s.profileForm.panNumber.slice(0, 5)}****${s.profileForm.panNumber.slice(-1)}` :
                                                            s.profileForm.panNumber
                                                    ) : "—"}
                                                </span>
                                                {s.profileForm.panVerified && (
                                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-semibold shrink-0">
                                                        <CheckCircle2 className="h-3 w-3" /> Verified
                                                    </span>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="mt-6 flex items-center justify-start border-t border-[#F0EBE1] pt-4">
                                        <button
                                            type="button"
                                            onClick={() => patch({ isEditingProfile: true })}
                                            className="cursor-pointer inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-[#E8E0D5] bg-white text-[12px] font-medium text-[#1A1A1A] hover:bg-[#F5F2EE] hover:border-[#D1C7BB] transition shadow-2xs active:scale-95"
                                        >
                                            <Pencil className="h-3.5 w-3.5 text-[#8B6914]" />
                                            <span>Edit Information</span>
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}

                    {/* ── ADDRESSES TAB ── */}
                    {s.activeTab === "address" && (
                        <div className="p-6">
                            <div className="flex items-center justify-between mb-5">
                                <h3 className="text-[18px] font-semibold text-[#1A1A1A]">Saved Address</h3>
                                {!s.isAddingAddress && (
                                    <button onClick={() => patch({ isAddingAddress: true, editingAddress: null, addrErrors: {} })} className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#8B6914] text-white text-[14px] font-medium hover:bg-[#7A5C10] transition">
                                        <Plus className="h-3 w-3" strokeWidth={2.5} /> Add New Address
                                    </button>
                                )}
                            </div>

                            {s.isAddingAddress && (
                                <div className="border border-[#E8E0D5] rounded-xl p-4 sm:p-5 mb-5 space-y-4 bg-[#FAFAF8]">
                                    <div className="space-y-1">
                                        <h4 className="text-[12px] font-semibold text-[#1A1A1A]">{s.editingAddress ? "Edit Address" : "Add New Address"}</h4>
                                        <button
                                            type="button"
                                            onClick={fetchCurrentLocation}
                                            disabled={s.isFetchingLocation}
                                            className="inline-flex items-center gap-1.5  pt-4 text-[14px] font-medium text-[#8B6914] hover:text-[#7A5C10] transition disabled:opacity-60"
                                        >
                                            {s.isFetchingLocation ? (
                                                <Loader2 className="h-3 w-3 animate-spin" />
                                            ) : (
                                                <MapPinned className="h-3 w-3" />
                                            )}
                                            {s.isFetchingLocation ? "Detecting your location..." : "Use my current location >"}
                                        </button>
                                    </div>
                                    {/* <div className="flex items-center gap-2">
                                        <div className="flex-1 h-px bg-[#E8E0D5]" />
                                        <span className="text-[14px] text-[#BEB5AA] font-medium">OR</span>
                                        <div className="flex-1 h-px bg-[#E8E0D5]" />
                                    </div> */}
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                        <div>
                                            <label className={labelCls}>Flat No<span className="text-rose-500 ml-1">*</span></label>
                                            <input
                                                value={s.addrForm.flatNo}
                                                onChange={(e) => {
                                                    patchAddrForm({ flatNo: e.target.value });
                                                    if (s.addrErrors.flatNo && e.target.value.trim()) {
                                                        patch({ addrErrors: removeErrorKey(s.addrErrors, "flatNo") });
                                                    }
                                                }}
                                                className={`${inputCls} ${s.addrErrors.flatNo ? "border-rose-400 focus:border-rose-400 focus:ring-rose-400/10" : ""}`}
                                            />
                                            {s.addrErrors.flatNo && <p className="text-[11px] text-rose-500 mt-1">{s.addrErrors.flatNo}</p>}
                                        </div>
                                        <div>
                                            <label className={labelCls}>Landmark<span className="text-rose-500 ml-1">*</span></label>
                                            <input
                                                value={s.addrForm.landMark}
                                                onChange={(e) => {
                                                    patchAddrForm({ landMark: e.target.value });
                                                    if (s.addrErrors.landMark && e.target.value.trim()) {
                                                        patch({ addrErrors: removeErrorKey(s.addrErrors, "landMark") });
                                                    }
                                                }}
                                                className={`${inputCls} ${s.addrErrors.landMark ? "border-rose-400 focus:border-rose-400 focus:ring-rose-400/10" : ""}`}
                                            />
                                            {s.addrErrors.landMark && <p className="text-[11px] text-rose-500 mt-1">{s.addrErrors.landMark}</p>}
                                        </div>
                                    </div>
                                    <div>
                                        <label className={labelCls}>Complete Address<span className="text-rose-500 ml-1">*</span></label>
                                        <textarea
                                            value={s.addrForm.address}
                                            onChange={(e) => {
                                                patchAddrForm({ address: e.target.value });
                                                if (s.addrErrors.address && e.target.value.trim()) {
                                                    patch({ addrErrors: removeErrorKey(s.addrErrors, "address") });
                                                }
                                            }}
                                            onBlur={geocodeAddressFields}
                                            className={`${inputCls} resize-none ${s.addrErrors.address ? "border-rose-400 focus:border-rose-400 focus:ring-rose-400/10" : ""}`}
                                            rows={2}
                                        />
                                        {s.addrErrors.address && <p className="text-[11px] text-rose-500 mt-1">{s.addrErrors.address}</p>}
                                    </div>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                        <div>
                                            <label className={labelCls}>Pin Code<span className="text-rose-500 ml-1">*</span></label>
                                            <input
                                                value={s.addrForm.pinCode}
                                                onChange={(e) => {
                                                    const formatted = formatPincode(e.target.value);
                                                    patchAddrForm({ pinCode: formatted });
                                                    if (formatted.length === 6) {
                                                        const pinErr = getPincodeError(formatted);
                                                        patch({ addrErrors: pinErr ? { ...s.addrErrors, pinCode: pinErr } : removeErrorKey(s.addrErrors, "pinCode") });
                                                        if (!pinErr) lookupPincode(formatted);
                                                    } else {
                                                        patch({ addrErrors: removeErrorKey(s.addrErrors, "pinCode") });
                                                        patchAddrForm({ state: "" });
                                                    }
                                                }}
                                                onBlur={() => {
                                                    if (!s.addrForm.pinCode) return;
                                                    const pinErr = getPincodeError(s.addrForm.pinCode);
                                                    if (pinErr) {
                                                        patch({ addrErrors: { ...s.addrErrors, pinCode: pinErr } });
                                                    } else {
                                                        patch({ addrErrors: removeErrorKey(s.addrErrors, "pinCode") });
                                                        geocodeAddressFields();
                                                    }
                                                }}
                                                inputMode="numeric"
                                                maxLength={6}
                                                placeholder="6-digit pin code"
                                                className={`${inputCls} ${s.addrErrors.pinCode ? "border-rose-400 focus:border-rose-400 focus:ring-rose-400/10" : ""}`}
                                            />
                                            {s.addrErrors.pinCode && <p className="text-[11px] text-rose-500 mt-1">{s.addrErrors.pinCode}</p>}
                                        </div>
                                        <div>
                                            <label className={labelCls}>State<span className="text-rose-500 ml-1">*</span></label>
                                            <input
                                                value={s.addrForm.state}
                                                onChange={(e) => {
                                                    patchAddrForm({ state: e.target.value });
                                                    const val = e.target.value.trim();
                                                    if (s.addrErrors.state && val && /^[a-zA-Z\s]+$/.test(val) && val.length >= 3) {
                                                        patch({ addrErrors: removeErrorKey(s.addrErrors, "state") });
                                                    }
                                                }}
                                                onBlur={geocodeAddressFields}
                                                className={`${inputCls} ${s.addrErrors.state ? "border-rose-400 focus:border-rose-400 focus:ring-rose-400/10" : ""}`}
                                            />
                                            {s.addrErrors.state && <p className="text-[11px] text-rose-500 mt-1">{s.addrErrors.state}</p>}
                                        </div>
                                    </div>
                                    {s.addrErrors.latitude && (
                                        <p className="text-[11px] text-amber-600 flex items-center gap-1">
                                            <AlertTriangle className="h-3 w-3" />
                                            {s.addrErrors.latitude}
                                        </p>
                                    )}
                                    <div className="flex flex-col-reverse sm:flex-row gap-3 pt-1">
                                        <button onClick={cancelAddrForm} className="w-full sm:w-auto px-4 py-2 rounded-lg border border-[#E8E0D5] text-[12px] font-medium text-[#8A8A8A] hover:bg-[#F5F2EE] transition">Cancel</button>
                                        <button onClick={handleSaveAddr} disabled={s.isAddressLoading} className="inline-flex w-full sm:w-auto justify-center items-center gap-2 px-4 py-2 rounded-lg bg-[#8B6914] text-white text-[12px] font-medium hover:bg-[#7A5C10] transition disabled:opacity-60">
                                            {s.isAddressLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
                                            {s.editingAddress ? "Update" : "Save Address"}
                                        </button>
                                    </div>
                                </div>
                            )}

                            {s.isAddressLoading && !s.isAddingAddress ? (
                                <div className="flex items-center justify-center py-12 gap-2 text-[#8A8A8A]">
                                    <Loader2 className="h-5 w-5 animate-spin" />
                                    <span className="text-[12px]">Loading address...</span>
                                </div>
                            ) : s.addresses.length === 0 && !s.isAddingAddress ? (
                                <div className="text-center py-16">
                                    <MapPin className="h-8 w-8 text-[#D1C7BB] mx-auto mb-3" />
                                    <p className="text-[12px] text-[#8A8A8A]">No address saved yet</p>
                                </div>
                            ) : (
                                <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
                                    {s.addresses.map((addr) => (
                                        <div key={addr.id} className="flex items-start gap-4 border border-[#E8E0D5] rounded-xl px-5 py-4 bg-white hover:border-[#C9B87A] transition">
                                            <div className="h-8 w-8 rounded-lg bg-[#F5EDD6] flex items-center justify-center text-[#8B6914] shrink-0 mt-0.5">
                                                <MapPin className="h-4 w-4" />
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <p className="text-[13px] font-semibold text-[#1A1A1A] truncate">{addr.address}</p>
                                                <p className="text-[11px] text-[#8A8A8A] mt-0.5">{[addr.flatNo, addr.landMark, addr.state, addr.pinCode].filter(Boolean).join(" · ")}</p>
                                            </div>
                                            <div className="flex items-center gap-2 shrink-0">
                                                <button onClick={() => handleEditAddress(addr)} className="h-7 w-7 flex items-center justify-center rounded-lg border border-[#E8E0D5] text-[#8A8A8A] hover:bg-[#F5EDD6] hover:text-[#8B6914] hover:border-[#C9B87A] transition">
                                                    <Pencil className="h-3 w-3" />
                                                </button>
                                                <button
                                                    onClick={() => patch({ deleteConfirmation: { show: true, addressId: addr.id } })}
                                                    className="h-7 w-7 flex items-center justify-center rounded-lg border border-[#E8E0D5] text-[#8A8A8A] hover:bg-rose-50 hover:text-rose-500 hover:border-rose-300 transition"
                                                >
                                                    <Trash2 className="h-3 w-3" />
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    )}

                    {/* ── WALLET TAB ── */}
                    {s.activeTab === "wallet" && (
                        <div className="p-6">
                            {s.isWalletLoading ? (
                                <div className="flex items-center justify-center py-16 gap-2 text-[#8A8A8A]">
                                    <Loader2 className="h-5 w-5 animate-spin" />
                                    <span className="text-[12px]">Loading wallet...</span>
                                </div>
                            ) : (
                                <>
                                    {/* Balance Card */}
                                    <div className="rounded-xl bg-[#1A1200] text-white px-6 py-5 mb-5 flex items-center justify-between shadow-md">
                                        <div>
                                            <p className="text-[10px] font-medium text-[#8A7A50] uppercase tracking-widest mb-1">Wallet Balance</p>
                                            <p className="text-[26px] font-semibold tracking-tight">{DISPLAY_INR(s.walletBalance)}</p>
                                        </div>
                                        <div className="h-12 w-12 rounded-full bg-[#8B6914]/20 flex items-center justify-center">
                                            <Wallet className="h-5 w-5 text-[#C9A84C]" />
                                        </div>
                                    </div>

                                    {/* Transactions */}
                                    <h4 className="text-[18px] font-semibold text-[#1A1A1A] mb-3">Transaction History</h4>
                                    {s.walletTransactions.length === 0 ? (
                                        <div className="text-center py-12">
                                            <History className="h-8 w-8 text-[#D1C7BB] mx-auto mb-3" />
                                            <p className="text-[12px] text-[#8A8A8A]">No transactions yet</p>
                                        </div>
                                    ) : (
                                        <div className="divide-y divide-[#F0EBE1] border border-[#E8E0D5] rounded-xl overflow-hidden">
                                            {s.walletTransactions.map((tx, i) => (
                                                <div key={i} className="flex items-center justify-between px-5 py-3.5 bg-white hover:bg-[#FAFAF8] transition">
                                                    <div className="flex items-center gap-3">
                                                        <div className={`h-7 w-7 rounded-full flex items-center justify-center ${tx.type === "CREDIT" ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-500"}`}>
                                                            {tx.type === "CREDIT" ? <Plus size={12} /> : <Minus size={12} />}
                                                        </div>
                                                        <div>
                                                            <p className="text-[13px] font-medium text-[#1A1A1A]">{tx.description || "Transaction"}</p>
                                                            <p className="text-[11px] text-[#8A8A8A]">{formatDate(tx.createdAt)}</p>
                                                        </div>
                                                    </div>
                                                    <span className={`text-[13px] font-semibold ${tx.type === "CREDIT" ? "text-emerald-600" : "text-[#1A1A1A]"}`}>
                                                        {tx.type === "CREDIT" ? "+" : "−"}{tx.amount?.toLocaleString("en-IN")}
                                                    </span>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </>
                            )}
                        </div>
                    )}

                    {/* ── ORDERS TAB ── */}
                    {s.activeTab === "orders" && (
                        <div className="p-6">
                            <h3 className="text-[18px] font-semibold text-[#1A1A1A] mb-5">Order History</h3>
                            {s.isOrdersLoading ? (
                                <div className="flex items-center justify-center py-16 gap-2 text-[#8A8A8A]">
                                    <Loader2 className="h-5 w-5 animate-spin" />
                                    <span className="text-[12px]">Loading orders...</span>
                                </div>
                            ) : s.orders.length === 0 ? (
                                <div className="text-center py-16">
                                    <ShoppingBag className="h-8 w-8 text-[#D1C7BB] mx-auto mb-3" />
                                    <p className="text-[13px] font-semibold text-[#1A1A1A] mb-1">No orders yet</p>
                                    <p className="text-[12px] text-[#8A8A8A] mb-5">Explore our collection and place your first order</p>
                                    <button onClick={() => navigate("/physical-gold")} className="px-5 py-2 rounded-lg bg-[#8B6914] text-white text-[12px] font-medium hover:bg-[#7A5C10] transition">Explore Collection</button>
                                </div>
                            ) : (
                                <div className="space-y-3">
                                    {s.orders.map((order) => {
                                        const isExp = s.expandedOrderId === order.orderId;
                                        const tracking = s.deliveryTracking[order.orderId];
                                        const isTrackingLoading = s.trackingLoadingOrderId === order.orderId;
                                        const trackingUnavailable = s.trackingErrorOrderId === order.orderId;
                                        const displayPaymentMode = order.paymentModeDisplay || (order.paymentMode?.toUpperCase() === 'CASHFREE' ? 'ONLINE' : order.paymentMode);
                                        const isPaymentPending = (order.paymentStatus?.toUpperCase() === 'PENDING' || order.paymentStatus?.toUpperCase() === 'PAYMENT_PENDING') &&
                                            order.orderStatus?.toUpperCase() !== 'EXPIRED' &&
                                            order.orderStatus?.toUpperCase() !== 'CANCELLED' &&
                                            order.orderStatus?.toUpperCase() !== 'FAILED';
                                        const isOrderSuccessful = order.orderStatus?.toUpperCase() === 'CONFIRMED' ||
                                            order.orderStatus?.toUpperCase() === 'DELIVERED' ||
                                            order.orderStatus?.toUpperCase() === 'COMPLETED' ||
                                            order.paymentStatus?.toUpperCase() === 'SUCCESS' ||
                                            order.paymentStatus?.toUpperCase() === 'COMPLETED' ||
                                            order.paymentStatus?.toUpperCase() === 'PAID';
                                        return (
                                            <div key={order.orderId} className="border border-[#E8E0D5] rounded-xl overflow-hidden bg-white">
                                                {/* Order Header */}
                                                <div
                                                    onClick={() => toggleOrderExpand(order.orderId)}
                                                    className="flex items-start gap-3 px-4 py-4 cursor-pointer hover:bg-[#FAF8F5] transition-colors"
                                                >
                                                    <div className="h-10 w-10 rounded-xl bg-[#F5EDD6] flex items-center justify-center text-[#8B6914] shrink-0 mt-0.5">
                                                        <Package className="h-5 w-5" />
                                                    </div>
                                                    <div className="flex-1 min-w-0">
                                                        <div className="flex items-start justify-between gap-2">
                                                            <div className="min-w-0">
                                                                <p className="text-[12px] font-semibold text-[#1A1A1A] truncate" title={order.orderNumber}>
                                                                    Order #{order.orderNumber}
                                                                </p>
                                                                <p className="text-[11px] text-[#8A8A8A] mt-0.5">
                                                                    {formatDate(order.createdAt || order.paymentExpiry)}
                                                                </p>
                                                            </div>
                                                            <div className="flex flex-col items-end gap-1.5 shrink-0">
                                                                <span className="text-[14px] font-bold text-[#1A1A1A]">{DISPLAY_INR(order.totalAmount)}</span>
                                                                {isPaymentPending && (
                                                                    <button
                                                                        type="button"
                                                                        disabled={retryingOrderId === order.orderId}
                                                                        onClick={(e) => {
                                                                            e.stopPropagation();
                                                                            handleRetryPayment(order);
                                                                        }}
                                                                        className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-[#8B6914] text-white text-[11px] font-medium hover:bg-[#7A5C10] transition shadow-sm disabled:opacity-60"
                                                                    >
                                                                        {retryingOrderId === order.orderId ? (
                                                                            <>
                                                                                <Loader2 className="h-3 w-3 animate-spin" />
                                                                                <span>Processing...</span>
                                                                            </>
                                                                        ) : (
                                                                            <>
                                                                                <CreditCard className="h-3 w-3" />
                                                                                <span>Make Payment</span>
                                                                            </>
                                                                        )}
                                                                    </button>
                                                                )}
                                                            </div>
                                                        </div>
                                                        <div className="flex flex-wrap items-center gap-1.5 mt-2">
                                                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap ${getStatusColor(order.orderStatus)}`}>
                                                                Order: {order.orderStatus}
                                                            </span>
                                                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap ${getStatusColor(order.paymentStatus)}`}>
                                                                Payment: {order.paymentStatus}
                                                            </span>
                                                            {displayPaymentMode && (
                                                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap ${getStatusColor(displayPaymentMode)}`}>
                                                                    {displayPaymentMode}
                                                                </span>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>

                                                {/* Actions */}
                                                <div className="flex items-center gap-2 px-4 pb-3 border-t border-[#F0EBE1] pt-3">
                                                    {isOrderSuccessful && (
                                                        <button
                                                            type="button"
                                                            onClick={async (e) => {
                                                                e.stopPropagation();
                                                                try {
                                                                    const res = await getInvoicePreviewUrl(order.orderNumber);
                                                                    const b = await res.blob();
                                                                    const u = URL.createObjectURL(b);
                                                                    window.open(u, "_blank");
                                                                } catch (err) { console.error(err); }
                                                            }}
                                                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#E8E0D5] text-[11px] font-medium text-[#8A8A8A] hover:bg-[#F5F2EE] transition"
                                                        >
                                                            <FileText className="h-3 w-3" /> Invoice
                                                        </button>
                                                    )}
                                                    <button
                                                        type="button"
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            toggleOrderExpand(order.orderId);
                                                        }}
                                                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#E8E0D5] text-[11px] font-medium text-[#1A1A1A] hover:bg-[#F5F2EE] transition ml-auto"
                                                    >
                                                        {isExp ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                                                        {isExp ? "Hide Details" : (isOrderSuccessful ? "Track Order" : "Order Details")}
                                                    </button>
                                                </div>


                                                {/* Expanded Details */}
                                                {isExp && (
                                                    <div className="border-t border-[#F0EBE1] bg-[#FAFAF8] px-5 py-4 space-y-3">
                                                        <div className="flex items-center justify-between mb-2">
                                                            <p className="text-[11px] font-semibold text-[#8A8A8A] uppercase tracking-wider">
                                                                Items · {order.totalItems} piece{order.totalItems > 1 ? "s" : ""}
                                                            </p>
                                                            <p className="text-[11px] text-[#8A8A8A]">{formatDate(order.paymentExpiry)}</p>
                                                        </div>

                                                        {isTrackingLoading ? (
                                                            <div className="flex items-center gap-2 rounded-xl border border-[#E8E0D5] bg-white px-4 py-3 text-[12px] text-[#8A8A8A]">
                                                                <Loader2 className="h-4 w-4 animate-spin text-[#8B6914]" /> Loading delivery updates...
                                                            </div>
                                                        ) : tracking ? (
                                                            <section className="rounded-xl border border-[#E8E0D5] bg-white overflow-hidden" aria-label="Delivery tracking">
                                                                {/* Status Banner */}
                                                                <div className="bg-gradient-to-r from-[#1A1200] to-[#2C2000] px-4 py-3 flex items-center justify-between gap-3">
                                                                    <div className="flex items-center gap-2.5 min-w-0">
                                                                        <div className="h-8 w-8 rounded-lg bg-[#8B6914]/30 flex items-center justify-center shrink-0">
                                                                            <Truck className="h-4 w-4 text-[#C9A84C]" />
                                                                        </div>
                                                                        <div className="min-w-0">
                                                                            <p className="text-[12px] font-semibold text-white truncate">{tracking.statusLabel || "In Transit"}</p>
                                                                            <p className="text-[10px] text-[#8A7A50] mt-0.5 truncate">{tracking.statusDescription || "Your order is on its way"}</p>
                                                                        </div>
                                                                    </div>
                                                                    <span className="shrink-0 rounded-full bg-emerald-500/20 border border-emerald-500/30 px-2.5 py-0.5 text-[10px] font-semibold text-emerald-400 whitespace-nowrap">
                                                                        {tracking.statusLabel || tracking.status || "Active"}
                                                                    </span>
                                                                </div>

                                                                <div className="p-4 space-y-3">
                                                                    {/* Meta info */}
                                                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                                                        {tracking.trackingNumber && (
                                                                            <div className="flex items-center gap-2 bg-[#F5F2EE] rounded-lg px-3 py-2">
                                                                                <span className="text-[10px] text-[#8A8A8A] shrink-0">Tracking ID</span>
                                                                                <span className="text-[11px] font-semibold text-[#1A1A1A] truncate ml-auto">{tracking.trackingNumber}</span>
                                                                            </div>
                                                                        )}
                                                                        {tracking.deliveryBoy && (
                                                                            <div className="flex items-center gap-2 bg-[#F5F2EE] rounded-lg px-3 py-2">
                                                                                <span className="text-[10px] text-[#8A8A8A] shrink-0">Partner</span>
                                                                                <span className="text-[11px] font-semibold text-[#1A1A1A] truncate ml-auto">
                                                                                    {`${tracking.deliveryBoy.firstName || ""} ${tracking.deliveryBoy.lastName || ""}`.trim() || "Assigned"}
                                                                                    {tracking.deliveryBoy.vehicleNumber ? ` · ${tracking.deliveryBoy.vehicleNumber}` : ""}
                                                                                </span>
                                                                            </div>
                                                                        )}
                                                                        {tracking.deliveryAddress && (
                                                                            <div className="flex items-start gap-2 bg-[#F5F2EE] rounded-lg px-3 py-2 sm:col-span-2">
                                                                                <MapPin className="h-3 w-3 text-[#8B6914] shrink-0 mt-0.5" />
                                                                                <span className="text-[11px] text-[#1A1A1A] leading-4">{tracking.deliveryAddress}</span>
                                                                            </div>
                                                                        )}
                                                                    </div>

                                                                    {/* Timeline */}
                                                                    {tracking.timeline?.length ? (
                                                                        <div>
                                                                            <p className="text-[10px] font-semibold text-[#8A8A8A] uppercase tracking-wider mb-2">Delivery Timeline</p>
                                                                            <ol className="space-y-0">
                                                                                {tracking.timeline.map((event: any, index: number) => {
                                                                                    const isFirst = index === 0;
                                                                                    const isLast = index === tracking.timeline!.length - 1;
                                                                                    return (
                                                                                        <li key={`${event.status}-${event.timestamp}`} className="relative flex gap-3">
                                                                                            <div className="flex flex-col items-center">
                                                                                                <div className={`h-5 w-5 rounded-full flex items-center justify-center shrink-0 z-10 mt-0.5 ${isFirst ? "bg-emerald-500" : "bg-[#E8E0D5]"}`}>
                                                                                                    {isFirst
                                                                                                        ? <CheckCircle2 className="h-3.5 w-3.5 text-white" />
                                                                                                        : <span className="h-2 w-2 rounded-full bg-[#BEB5AA]" />}
                                                                                                </div>
                                                                                                {!isLast && <span className="w-px flex-1 bg-[#E8E0D5] my-1" />}
                                                                                            </div>
                                                                                            <div className={`pb-3 min-w-0 ${isLast ? "pb-0" : ""}`}>
                                                                                                <p className={`text-[12px] font-semibold ${isFirst ? "text-[#1A1A1A]" : "text-[#8A8A8A]"}`}>{event.statusLabel}</p>
                                                                                                {event.description && <p className="text-[11px] text-[#8A8A8A] mt-0.5 leading-4">{event.description}</p>}
                                                                                                <p className="text-[10px] text-[#BEB5AA] mt-0.5">{formatDate(event.timestamp)}</p>
                                                                                            </div>
                                                                                        </li>
                                                                                    );
                                                                                })}
                                                                            </ol>
                                                                        </div>
                                                                    ) : null}
                                                                </div>
                                                            </section>
                                                        ) : trackingUnavailable ? (
                                                            <div className="rounded-xl border border-[#E8E0D5] bg-[#FAFAF8] px-4 py-4 flex items-center gap-3">
                                                                <div className="h-8 w-8 rounded-lg bg-[#F5EDD6] flex items-center justify-center shrink-0">
                                                                    <Truck className="h-4 w-4 text-[#8B6914]" />
                                                                </div>
                                                                <p className="text-[12px] text-[#6D6D6D] leading-4">Tracking will appear here once your order is out for delivery.</p>
                                                            </div>
                                                        ) : null}

                                                        {order.items?.map((item: any, i: number) => {
                                                            const existingReview = reviews.find((r) => r.productId === item.productId);
                                                            return (
                                                                <div key={i} className="bg-white border border-[#E8E0D5] rounded-xl px-4 py-3.5">
                                                                    <div className="flex items-start gap-3">
                                                                        <div className="h-9 w-9 rounded-lg bg-[#F5EDD6] flex items-center justify-center text-[#8B6914] shrink-0 mt-0.5">
                                                                            <Package className="h-4 w-4" />
                                                                        </div>
                                                                        <div className="flex-1 min-w-0">
                                                                            <div className="flex items-start justify-between gap-2">
                                                                                <p className="text-[13px] font-semibold text-[#1A1A1A] leading-snug">
                                                                                    {item.productName || `Product #${item.productId}`}
                                                                                </p>
                                                                                <p className="text-[13px] font-semibold text-[#1A1A1A] shrink-0">{DISPLAY_INR(item.subtotal)}</p>
                                                                            </div>
                                                                            {item.variant && (
                                                                                <p className="text-[11px] text-[#8B6914] font-medium mt-0.5">{item.variant}</p>
                                                                            )}
                                                                            <p className="text-[11px] text-[#8A8A8A] mt-0.5">
                                                                                Qty: {item.quantity} · {DISPLAY_INR(item.price)} per pc
                                                                            </p>
                                                                            <div className="mt-2 space-y-1.5">
                                                                                {existingReview && (
                                                                                    <div className="flex items-center justify-between gap-2">
                                                                                        <div className="flex items-center gap-0.5">
                                                                                            {[1, 2, 3, 4, 5].map((star) => (
                                                                                                <Star key={star} className="h-3 w-3"
                                                                                                    fill={star <= existingReview.rating ? "#F5B301" : "none"}
                                                                                                    stroke={star <= existingReview.rating ? "#F5B301" : "#D1C7BB"}
                                                                                                />
                                                                                            ))}
                                                                                            <span className="ml-1 text-[11px] text-[#8A8A8A] font-medium">{REVIEW_RATING_LABELS[existingReview.rating]}</span>
                                                                                        </div>
                                                                                        {order.orderStatus?.toUpperCase() === "DELIVERED" && (
                                                                                            <button
                                                                                                type="button"
                                                                                                onClick={() => openProductReview(item)}
                                                                                                className="hidden sm:inline-flex items-center gap-1 text-[11px] font-semibold text-[#8B6914] hover:text-[#5f470d] shrink-0"
                                                                                            >
                                                                                                <Star className="h-3 w-3 shrink-0" fill="#F5B301" stroke="#8B6914" />
                                                                                                Edit rating
                                                                                            </button>
                                                                                        )}
                                                                                    </div>
                                                                                )}
                                                                                {order.orderStatus?.toUpperCase() === "DELIVERED" && (
                                                                                    <button
                                                                                        type="button"
                                                                                        onClick={() => openProductReview(item)}
                                                                                        className={`inline-flex items-center gap-1 text-[11px] font-semibold text-[#8B6914] hover:text-[#5f470d] ${existingReview ? "sm:hidden" : ""}`}
                                                                                    >
                                                                                        <Star className="h-3 w-3 shrink-0" fill={existingReview ? "#F5B301" : "none"} stroke="#8B6914" />
                                                                                        {existingReview ? "Edit rating" : "Rate product"}
                                                                                    </button>
                                                                                )}
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            );
                                                        })}

                                                        {/* Delivery Address (if available and not in tracking) */}
                                                        {(order.address || order.flatNo) && !tracking?.deliveryAddress && (
                                                            <div className="flex items-start gap-2 bg-[#F5F2EE] rounded-lg px-3 py-2 text-[11px] text-[#1A1A1A]">
                                                                <MapPin className="h-3.5 w-3.5 text-[#8B6914] shrink-0 mt-0.5" />
                                                                <div className="leading-4">
                                                                    <p className="font-semibold text-[#1A1A1A]">Delivery Address</p>
                                                                    <p className="text-[#6D6D6D]">
                                                                        {[order.flatNo, order.address, order.landMark, order.state, order.pinCode].filter(Boolean).join(", ")}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        )}

                                                        {/* Order Summary Row */}
                                                        <div className="bg-white border border-[#E8E0D5] rounded-lg p-3 space-y-1.5 text-[11px]">
                                                            <div className="flex justify-between text-[#8A8A8A]">
                                                                <span>Items ({order.totalItems} piece{order.totalItems > 1 ? "s" : ""})</span>
                                                                <span>{DISPLAY_INR(order.items?.reduce((sum, item) => sum + (item.subtotal || item.price * item.quantity), 0) || order.totalAmount)}</span>
                                                            </div>
                                                            {typeof order.totalDiscountAmount === 'number' && order.totalDiscountAmount > 0 && (
                                                                <div className="flex justify-between text-emerald-600 font-medium">
                                                                    <span>Discount</span>
                                                                    <span>-{DISPLAY_INR(order.totalDiscountAmount)}</span>
                                                                </div>
                                                            )}
                                                            {order.deliveryFee !== null && order.deliveryFee !== undefined && (
                                                                <div className="flex justify-between text-[#8A8A8A]">
                                                                    <span>Delivery Fee</span>
                                                                    <span>{order.deliveryFee > 0 ? DISPLAY_INR(order.deliveryFee) : "FREE"}</span>
                                                                </div>
                                                            )}
                                                            <div className="flex justify-between text-[#1A1A1A] font-semibold pt-1.5 border-t border-[#F0EBE1] text-[12px]">
                                                                <span>Total Amount</span>
                                                                <span>{DISPLAY_INR(order.totalAmount)}</span>
                                                            </div>
                                                        </div>

                                                        {/* Payment Info */}
                                                        <div className="bg-[#1A1200] text-white rounded-lg px-3 py-3 mt-2 flex items-center justify-between gap-2">
                                                            <div className="flex items-center gap-2 min-w-0">
                                                                <CreditCard className="h-3.5 w-3.5 text-[#C9A84C] shrink-0" />
                                                                <span className="text-[11px] font-medium truncate">
                                                                    {displayPaymentMode}
                                                                    {order.txnId ? ` · Txn: ${order.txnId}` : ""}
                                                                </span>
                                                            </div>
                                                            <span className={`shrink-0 px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap ${getStatusColor(order.paymentStatus)}`}>
                                                                {order.paymentStatus}
                                                            </span>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    )}
                    {/* ── SUPPORT TAB ── */}
                    {s.activeTab === "support" && (
                        <div className="p-6">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="text-[18px] font-semibold text-[#1A1A1A]">Help & Support</h3>
                                {!s.showQueryForm && (
                                    <button
                                        onClick={() => patch({ showQueryForm: true, queryFormErrors: {} })}
                                        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#8B6914] text-white text-[14px] font-medium hover:bg-[#7A5C10] transition"
                                    >
                                        <Plus className="h-3 w-3" strokeWidth={2.5} /> New Query
                                    </button>
                                )}
                            </div>

                            {/* Status Filter */}
                            {!s.showQueryForm && (
                                <div className="mb-5 max-w-xs">
                                    <label htmlFor="query-status" className={labelCls}>Query status</label>
                                    <div className="relative">
                                        <select
                                            id="query-status"
                                            value={s.queryStatusFilter}
                                            onChange={(event) => {
                                                const status = event.target.value;
                                                patch({ queryStatusFilter: status, queries: [] });
                                                loadQueries(status);
                                            }}
                                            className={`${inputCls} appearance-none pr-9 font-medium cursor-pointer`}
                                        >
                                            <option value="PENDING">Pending</option>
                                            <option value="COMPLETED">Completed</option>
                                            <option value="CANCELLED">Cancelled</option>
                                        </select>
                                        <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8A8A8A]" />
                                    </div>
                                </div>
                            )}

                            {/* New Query Form */}
                            {s.showQueryForm && (
                                <div className="border border-[#E8E0D5] rounded-xl p-5 mb-5 space-y-4 bg-[#FAFAF8]">
                                    <h4 className="text-[13px] font-semibold text-[#1A1A1A]">Submit a New Query</h4>

                                    {/* Auto-filled contact info */}
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                        <div>
                                            <label className={labelCls}>Email <span className="text-rose-500">*</span></label>
                                            <input
                                                type="email"
                                                value={s.profileForm.email || ''}
                                                disabled={!!s.profileForm.email && validateEmail(s.profileForm.email)}
                                                onChange={(e) => {
                                                    patchProfile({ email: e.target.value });
                                                    patch({ queryFormErrors: { ...s.queryFormErrors, email: '' } });
                                                }}
                                                placeholder="Enter your email"
                                                className={`${inputCls} ${s.profileForm.email && validateEmail(s.profileForm.email) ? 'bg-[#F5F2EE] cursor-not-allowed opacity-70' : !s.profileForm.email ? 'border-amber-300 focus:border-amber-500' : ''}`}
                                            />
                                            {s.queryFormErrors.email && <p className="text-[11px] text-rose-500 mt-1">{s.queryFormErrors.email}</p>}
                                        </div>
                                        <div>
                                            <label className={labelCls}>Mobile Number <span className="text-rose-500">*</span></label>
                                            <input
                                                type="tel"
                                                value={s.profileForm.mobileNumber || ''}
                                                disabled={!!s.profileForm.mobileNumber && validateMobileNumber(s.profileForm.mobileNumber)}
                                                onChange={(e) => {
                                                    const val = formatMobileNumber(e.target.value);
                                                    if (val.length <= 10) {
                                                        patchProfile({ mobileNumber: val });
                                                        patch({ queryFormErrors: { ...s.queryFormErrors, mobileNumber: '' } });
                                                    }
                                                }}
                                                placeholder="Enter 10-digit mobile number"
                                                maxLength={10}
                                                className={`${inputCls} ${s.profileForm.mobileNumber && validateMobileNumber(s.profileForm.mobileNumber) ? 'bg-[#F5F2EE] cursor-not-allowed opacity-70' : !s.profileForm.mobileNumber ? 'border-amber-300 focus:border-amber-500' : ''}`}
                                            />
                                            {s.queryFormErrors.mobileNumber && <p className="text-[11px] text-rose-500 mt-1">{s.queryFormErrors.mobileNumber}</p>}
                                        </div>
                                    </div>

                                    <div>
                                        <label className={labelCls}>Your Query <span className="text-rose-500">*</span></label>
                                        <textarea
                                            value={s.queryForm.query}
                                            onChange={(e) => patch({
                                                queryForm: { ...s.queryForm, query: e.target.value },
                                                queryFormErrors: { ...s.queryFormErrors, query: '' },
                                            })}
                                            placeholder="Describe your issue or question..."
                                            className={`${inputCls} resize-none`}
                                            rows={3}
                                        />
                                        {s.queryFormErrors.query && <p className="text-[11px] text-rose-500 mt-1">{s.queryFormErrors.query}</p>}
                                    </div>

                                    {/* File Upload (optional) */}
                                    <div>
                                        <label className={labelCls}>Attach Screenshot <span className="text-[#BEB5AA]">(optional)</span></label>
                                        {s.queryForm.file ? (
                                            <div className="flex items-center gap-2 px-3 py-2 border border-[#E8E0D5] rounded-lg bg-white">
                                                <Paperclip className="h-3.5 w-3.5 text-[#8B6914] shrink-0" />
                                                <span className="text-[12px] text-[#1A1A1A] flex-1 truncate">{s.queryForm.file.name}</span>
                                                <button
                                                    onClick={() => patch({ queryForm: { ...s.queryForm, file: null } })}
                                                    className="text-[#8A8A8A] hover:text-rose-500 transition"
                                                >
                                                    <X className="h-3.5 w-3.5" />
                                                </button>
                                            </div>
                                        ) : (
                                            <label className="flex items-center gap-2 px-3 py-2 border border-dashed border-[#E8E0D5] rounded-lg bg-white cursor-pointer hover:border-[#8B6914] transition">
                                                <Paperclip className="h-3.5 w-3.5 text-[#8A8A8A]" />
                                                <span className="text-[12px] text-[#8A8A8A]">Click to attach a file</span>
                                                <input
                                                    type="file"
                                                    accept="image/*"
                                                    className="hidden"
                                                    onChange={(e) => {
                                                        const file = e.target.files?.[0] || null;
                                                        if (!file) return;
                                                        const allowed = file.type.startsWith('image/');
                                                        if (!allowed) {
                                                            patch({ queryFormErrors: { ...s.queryFormErrors, file: 'Only image files are allowed.' } });
                                                            e.target.value = '';
                                                            return;
                                                        }
                                                        if (file.size > 5 * 1024 * 1024) {
                                                            patch({ queryFormErrors: { ...s.queryFormErrors, file: 'Attachment must be 5 MB or smaller.' } });
                                                            e.target.value = '';
                                                            return;
                                                        }
                                                        patch({
                                                            queryForm: { ...s.queryForm, file },
                                                            queryFormErrors: { ...s.queryFormErrors, file: '' },
                                                        });
                                                    }}
                                                />
                                            </label>
                                        )}
                                        {s.queryFormErrors.file && <p className="text-[11px] text-rose-500 mt-1">{s.queryFormErrors.file}</p>}
                                    </div>

                                    <div className="flex gap-3 pt-1">
                                        <button
                                            onClick={() => patch({ showQueryForm: false, queryForm: { query: '', comments: '', file: null }, queryFormErrors: {} })}
                                            className="px-4 py-2 rounded-lg border border-[#E8E0D5] text-[12px] font-medium text-[#8A8A8A] hover:bg-[#F5F2EE] transition"
                                        >
                                            Cancel
                                        </button>
                                        <button
                                            onClick={handleSubmitQuery}
                                            disabled={s.isSubmittingQuery || s.isUploadingFile}
                                            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#8B6914] text-white text-[12px] font-medium hover:bg-[#7A5C10] transition disabled:opacity-60"
                                        >
                                            {s.isUploadingFile ? (
                                                <><Loader2 className="h-3.5 w-3.5 animate-spin" /> Uploading...</>
                                            ) : s.isSubmittingQuery ? (
                                                <><Loader2 className="h-3.5 w-3.5 animate-spin" /> Submitting...</>
                                            ) : (
                                                <><Send className="h-3.5 w-3.5" /> Submit Query</>
                                            )}
                                        </button>
                                    </div>
                                </div>
                            )}

                            {/* Queries List */}
                            {!s.showQueryForm && (s.isQueriesLoading ? (
                                <div className="flex items-center justify-center py-16 gap-2 text-[#8A8A8A]">
                                    <Loader2 className="h-5 w-5 animate-spin" />
                                    <span className="text-[12px]">Loading queries...</span>
                                </div>
                            ) : s.queries.length === 0 ? (
                                <div className="text-center py-16">
                                    <MessageSquare className="h-8 w-8 text-[#D1C7BB] mx-auto mb-3" />
                                    <p className="text-[13px] font-semibold text-[#1A1A1A] mb-1">No queries yet</p>
                                    <p className="text-[12px] text-[#8A8A8A]">Submit a query and our team will get back to you</p>
                                </div>
                            ) : (
                                <div className="space-y-3">
                                    {s.queries.map((q) => (
                                        <div key={q.id} className="border border-[#E8E0D5] rounded-xl bg-white overflow-hidden">
                                            <div className="px-4 py-4">
                                                <div className="flex items-start justify-between gap-3 mb-2">
                                                    <div className="flex items-center gap-2">
                                                        <span className="text-[10px] font-semibold text-[#8A8A8A] uppercase tracking-wider">
                                                            #{q.randomTicketId || q.ticketId}
                                                        </span>
                                                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${q.queryStatus === 'COMPLETED'
                                                            ? 'bg-emerald-50 text-emerald-700'
                                                            : q.queryStatus === 'PENDING'
                                                                ? 'bg-amber-50 text-amber-700'
                                                                : q.queryStatus === 'CANCELLED'
                                                                    ? 'bg-rose-50 text-rose-700'
                                                                    : 'bg-blue-50 text-blue-700'
                                                            }`}>
                                                            {q.queryStatus}
                                                        </span>
                                                    </div>
                                                    <span className="text-[11px] text-[#8A8A8A] shrink-0">
                                                        {q.createdAt ? new Date(q.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                                                    </span>
                                                </div>
                                                <p className="text-[13px] font-medium text-[#1A1A1A] mb-1">{q.query}</p>
                                                {q.comments && (
                                                    <p className="text-[12px] text-[#8A8A8A]">{q.comments}</p>
                                                )}
                                                {q.resolvedBy && (
                                                    <div className="mt-3 pt-3 border-t border-[#F0EBE1] flex items-center gap-2">
                                                        <CheckCheck className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
                                                        <p className="text-[12px] text-emerald-700 font-medium">Cancelled by {q.resolvedBy}</p>
                                                    </div>
                                                )}
                                                {/* User Documents */}
                                                {q.userDocuments?.length > 0 && (
                                                    <div className="mt-3 pt-3 border-t border-[#F0EBE1]">
                                                        <p className="text-[10px] font-semibold text-[#8A8A8A] uppercase tracking-wider mb-2">Attachments</p>
                                                        <div className="flex flex-wrap gap-2">
                                                            {q.userDocuments.map((doc: any) => {
                                                                const filePath = doc.filePath || doc.adminUploadedFilePath || "";
                                                                const resolvedUrl = resolveS3ImageUrl(filePath);
                                                                const fileName = doc.fileName || doc.adminUploadedFileName || "Attachment";
                                                                const isImage = /\.(jpg|jpeg|png|gif|webp|svg)/i.test(fileName) || /\.(jpg|jpeg|png|gif|webp|svg)/i.test(filePath);
                                                                return (
                                                                    <a
                                                                        key={doc.userDocumentId || doc.adminDocumentId || filePath}
                                                                        href={resolvedUrl}
                                                                        target="_blank"
                                                                        rel="noopener noreferrer"
                                                                        className="group relative inline-block"
                                                                        title={fileName}
                                                                    >
                                                                        {isImage ? (
                                                                            <div className="h-16 w-16 rounded-lg border border-[#E8E0D5] overflow-hidden bg-[#F5F2EE] hover:border-[#8B6914] transition">
                                                                                <img
                                                                                    src={resolvedUrl}
                                                                                    alt={fileName}
                                                                                    className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-200"
                                                                                    onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                                                                                />
                                                                            </div>
                                                                        ) : (
                                                                            <div className="flex items-center gap-1.5 px-3 py-1.5 border border-[#E8E0D5] rounded-lg bg-white hover:bg-[#F5F2EE] transition">
                                                                                <Paperclip className="h-3 w-3 text-[#8A8A8A]" />
                                                                                <span className="text-[11px] text-[#1A1A1A] max-w-[120px] truncate">{fileName}</span>
                                                                            </div>
                                                                        )}
                                                                    </a>
                                                                );
                                                            })}
                                                        </div>
                                                    </div>
                                                )}
                                                {q.queryStatus?.toUpperCase() === 'PENDING' && (
                                                    <div className="mt-3 pt-3 border-t border-[#F0EBE1]">
                                                        <div className="flex justify-end">
                                                            <button
                                                                type="button"
                                                                onClick={() => patch({ cancelQueryConfirmation: { show: true, queryId: q.id, ticketNumber: q.randomTicketId || String(q.ticketId || q.id) } })}
                                                                disabled={s.cancellingQueryId === q.id}
                                                                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-rose-200 text-[11px] font-semibold text-rose-600 hover:bg-rose-50 transition disabled:opacity-60"
                                                            >
                                                                {s.cancellingQueryId === q.id
                                                                    ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                                                    : <X className="h-3.5 w-3.5" />}
                                                                Cancel Query
                                                            </button>
                                                        </div>
                                                    </div>
                                                )}
                                                {q.userPendingQueries?.length > 0 && (
                                                    <div className="mt-3 pt-3 border-t border-[#F0EBE1] space-y-2">
                                                        {q.userPendingQueries.map((pq) => (
                                                            <div key={pq.id} className="bg-[#FAFAF8] rounded-lg px-3 py-2">
                                                                <p className="text-[12px] text-[#1A1A1A]">{pq.message || pq.pendingComments}</p>
                                                                <p className="text-[10px] text-[#8A8A8A] mt-1">{pq.createdAt}</p>
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </main>

            {reviewItem && (
                <div className="fixed inset-0 z-[100] flex items-end justify-center bg-black/55 sm:items-center sm:p-4" onMouseDown={closeProductReview}>
                    <div className="max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl bg-white p-4 shadow-2xl sm:max-w-md sm:rounded-2xl sm:p-5" onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-labelledby="review-title">
                        <div className="flex items-start justify-between gap-4">
                            <div>
                                <h3 id="review-title" className="text-[18px] font-semibold text-[#1A1A1A]">{editingReview ? "Edit your review" : "Write a product review"}</h3>
                                <p className="mt-1 text-[12px] text-[#8A8A8A]">Help other customers make a confident choice.</p>
                            </div>
                            <button type="button" onClick={closeProductReview} aria-label="Close review form" className="rounded-lg p-1 text-[#8A8A8A] hover:bg-[#F5F2EE]"><X className="h-4 w-4" /></button>
                        </div>
                        <div className="mt-3 rounded-lg border border-[#EFE7DC] bg-[#FCFAF7] px-3 py-2">
                            <p className="truncate text-[13px] font-semibold text-[#1A1A1A]">{reviewItem.productName || `Product #${reviewItem.productId}`}</p>
                            <p className="mt-1 inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700"><CheckCircle2 className="h-3 w-3" /> Verified purchase</p>
                        </div>
                        <div className="my-3 text-center" aria-label="Choose rating">
                            <p className="mb-1 text-[11px] font-semibold text-[#4A443E]">How would you rate this product?</p>
                            <div className="flex justify-center gap-2">{[1, 2, 3, 4, 5].map((value) => (
                                <button type="button" key={value} onClick={() => { setReviewRating(value); setReviewError(""); }} aria-label={`${value} star${value > 1 ? "s" : ""}`} className="rounded-lg p-1 focus:outline-none focus:ring-2 focus:ring-[#C9A84C]/30">
                                    <Star className="h-7 w-7 transition-transform hover:scale-110" fill={value <= reviewRating ? "#F5B301" : "none"} stroke={value <= reviewRating ? "#F5B301" : "#D1C7BB"} />
                                </button>
                            ))}</div>
                            <p className={`mt-1 min-h-4 text-[11px] font-semibold ${reviewRating ? "text-[#8B6914]" : "text-[#A59B90]"}`}>{reviewRating ? REVIEW_RATING_LABELS[reviewRating] : "Tap a star to rate"}</p>
                        </div>
                        <label className={labelCls}>Add a headline <span className="text-rose-500">*</span></label>
                        <input value={reviewTitle} onChange={(event) => { setReviewTitle(event.target.value); setReviewError(""); }} minLength={REVIEW_TITLE_MIN} maxLength={80} placeholder="What stood out most?" className={inputCls} />
                        <p className="mb-2 mt-0.5 flex justify-between text-[9px] text-[#8A8A8A]"><span>Minimum {REVIEW_TITLE_MIN} characters</span><span>{reviewTitle.length}/80</span></p>
                        <label className={labelCls}>Share your experience <span className="text-rose-500">*</span></label>
                        <textarea value={reviewText} onChange={(event) => { setReviewText(event.target.value); setReviewError(""); }} minLength={REVIEW_TEXT_MIN} maxLength={1000} rows={3} placeholder="Share your experience with quality, fit and packaging" className={`${inputCls} resize-none`} />
                        <p className="mt-0.5 flex justify-between text-[9px] text-[#8A8A8A]"><span>Minimum {REVIEW_TEXT_MIN} characters</span><span>{reviewText.length}/1000</span></p>
                        <label className="mt-3 flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-[#D1C7BB] px-3 py-3 text-[12px] font-medium text-[#6B6B6B] hover:bg-[#FAFAF8]">
                            <ImagePlus className="h-4 w-4 text-[#8B6914]" />
                            <span className="min-w-0 truncate">{reviewFile ? reviewFile.name : "Add photo or video (optional)"}</span>
                            <input type="file" accept=".jpg,.jpeg,.png,.webp,.mp4,.webm" className="hidden" onChange={(event) => selectReviewFile(event.target.files?.[0] || null)} />
                        </label>
                        {reviewFile && <button type="button" onClick={() => setReviewFile(null)} className="mt-2 text-[11px] font-semibold text-rose-600 hover:underline">Remove selected file</button>}
                        <p className="mt-1 text-[10px] text-[#8A8A8A]">Images up to 10 MB · Videos up to 50 MB</p>
                        {reviewError && <p role="alert" className="mt-3 rounded-lg bg-rose-50 px-3 py-2 text-[12px] font-medium text-rose-600">{reviewError}</p>}
                        <button type="button" onClick={saveProductReview} disabled={isSavingReview} className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#8B6914] px-4 py-2 text-[13px] font-semibold text-white hover:bg-[#7A5C10] disabled:opacity-60">
                            {isSavingReview && <Loader2 className="h-4 w-4 animate-spin" />}
                            {isSavingReview ? "Saving..." : editingReview ? "Update review" : "Submit review"}
                        </button>
                        <p className="mt-1 text-center text-[9px] text-[#8A8A8A]">Your review will be visible after moderation.</p>
                    </div>
                </div>
            )}

            {/* Profile Incomplete Modal */}
            {s.profileIncompleteModal && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
                    <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full p-6">
                        <div className="flex items-center gap-3 mb-3">
                            <div className="h-10 w-10 rounded-full bg-amber-50 flex items-center justify-center shrink-0">
                                <AlertTriangle className="h-5 w-5 text-amber-600" />
                            </div>
                            <h3 className="text-[15px] font-semibold text-[#1A1A1A]">Complete Your Profile</h3>
                        </div>
                        <p className="text-[13px] text-[#6B6B6B] mb-5 leading-relaxed">
                            Please complete your profile (name, email, mobile) to continue.
                        </p>
                        <div className="flex gap-3">
                            <button
                                onClick={() => patch({ profileIncompleteModal: false })}
                                className="flex-1 px-4 py-2.5 rounded-lg border border-[#E8E0D5] text-[12px] font-medium text-[#6B6B6B] hover:bg-[#F5F2EE] transition"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={() => {
                                    patch({ profileIncompleteModal: false, activeTab: "info", isEditingProfile: true });
                                    const currentReturnTo = returnTo || searchParams.get("returnTo") || "";
                                    setSearchParams({ tab: "info", ...(currentReturnTo ? { returnTo: currentReturnTo } : { returnTo: "support" }) });
                                }}
                                className="flex-1 px-4 py-2.5 rounded-lg bg-[#8B6914] text-white text-[12px] font-medium hover:bg-[#7A5C10] transition"
                            >
                                Complete Profile
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Delete Confirmation Modal */}
            {s.deleteConfirmation.show && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
                    <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 animate-in fade-in zoom-in duration-200">
                        <div className="flex items-center gap-3 mb-4">
                            <div className="h-10 w-10 rounded-full bg-rose-50 flex items-center justify-center">
                                <Trash2 className="h-5 w-5 text-rose-500" />
                            </div>
                            <h3 className="text-[16px] font-semibold text-[#1A1A1A]">Delete Address</h3>
                        </div>
                        <p className="text-[13px] text-[#8A8A8A] mb-6">
                            Are you sure you want to delete this address? This action cannot be undone.
                        </p>
                        <div className="flex gap-3">
                            <button
                                onClick={() => patch({ deleteConfirmation: { show: false, addressId: null } })}
                                className="flex-1 px-4 py-2.5 rounded-lg border border-[#E8E0D5] text-[13px] font-medium text-[#1A1A1A] hover:bg-[#F5F2EE] transition"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={() => s.deleteConfirmation.addressId && handleDeleteAddress(s.deleteConfirmation.addressId)}
                                disabled={s.isAddressLoading}
                                className="flex-1 px-4 py-2.5 rounded-lg bg-rose-500 text-white text-[13px] font-medium hover:bg-rose-600 transition disabled:opacity-60 inline-flex items-center justify-center gap-2"
                            >
                                {s.isAddressLoading ? (
                                    <>
                                        <Loader2 className="h-4 w-4 animate-spin" />
                                        Deleting...
                                    </>
                                ) : (
                                    <>
                                        <Trash2 className="h-4 w-4" />
                                        Delete
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Cancel Query Confirmation Modal */}
            {s.cancelQueryConfirmation.show && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
                    <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 animate-in fade-in zoom-in duration-200">
                        <div className="flex items-center gap-3 mb-4">
                            <div className="h-10 w-10 rounded-full bg-rose-50 flex items-center justify-center">
                                <AlertTriangle className="h-5 w-5 text-rose-500" />
                            </div>
                            <h3 className="text-[16px] font-semibold text-[#1A1A1A]">Cancel Query</h3>
                        </div>
                        <p className="text-[13px] text-[#6B6B6B] mb-6 leading-relaxed">
                            Are you sure you want to cancel query <strong className="text-[#1A1A1A]">#{s.cancelQueryConfirmation.ticketNumber}</strong>? This action cannot be undone.
                        </p>
                        <div className="flex gap-3">
                            <button
                                type="button"
                                onClick={() => patch({ cancelQueryConfirmation: { show: false, queryId: null, ticketNumber: '' } })}
                                className="flex-1 px-4 py-2.5 rounded-lg border border-[#E8E0D5] text-[13px] font-medium text-[#1A1A1A] hover:bg-[#F5F2EE] transition"
                            >
                                No, Keep Query
                            </button>
                            <button
                                type="button"
                                onClick={() => s.cancelQueryConfirmation.queryId && handleCancelQuery(s.cancelQueryConfirmation.queryId)}
                                disabled={s.cancellingQueryId === s.cancelQueryConfirmation.queryId}
                                className="flex-1 px-4 py-2.5 rounded-lg bg-rose-600 text-white text-[13px] font-medium hover:bg-rose-700 transition disabled:opacity-60 inline-flex items-center justify-center gap-2"
                            >
                                {s.cancellingQueryId === s.cancelQueryConfirmation.queryId ? (
                                    <>
                                        <Loader2 className="h-4 w-4 animate-spin" />
                                        Cancelling...
                                    </>
                                ) : (
                                    "Yes, Cancel Query"
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Logout Confirmation Modal */}
            {showLogoutConfirm && (
                <div
                    className="fixed inset-0 z-[9999] flex items-center justify-center px-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
                    onClick={() => !isLoggingOut && setShowLogoutConfirm(false)}
                >
                    <div
                        className="bg-white border border-[#E8E0D5] rounded-2xl shadow-2xl w-full max-w-sm p-6 relative overflow-hidden"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <button
                            type="button"
                            disabled={isLoggingOut}
                            onClick={() => setShowLogoutConfirm(false)}
                            className="absolute right-4 top-4 h-7 w-7 flex items-center justify-center rounded-full text-[#8A8A8A] hover:bg-[#F5F2EE] hover:text-[#1A1A1A] transition cursor-pointer"
                        >
                            <X className="h-4 w-4" />
                        </button>
                        <div className="flex items-center gap-3 mb-3">
                            <div className="h-11 w-11 rounded-full bg-rose-50 border border-rose-100 flex items-center justify-center shrink-0">
                                <LogOut className="h-5 w-5 text-rose-500" />
                            </div>
                            <div>
                                <h3 className="text-[16px] font-bold text-[#1A1A1A]">Confirm Log Out</h3>
                                <p className="text-[12px] text-[#8A8A8A]">You will need to sign in again</p>
                            </div>
                        </div>
                        <p className="text-[13px] text-[#5A5A5A] mb-6 leading-relaxed">
                            Are you sure you want to log out of your OxyGold account?
                        </p>
                        <div className="flex items-center gap-3">
                            <button
                                type="button"
                                disabled={isLoggingOut}
                                onClick={() => setShowLogoutConfirm(false)}
                                className="flex-1 px-4 py-2.5 rounded-xl border border-[#E8E0D5] text-[13px] font-medium text-[#5A5A5A] hover:bg-[#F5F2EE] transition cursor-pointer disabled:opacity-50"
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                disabled={isLoggingOut}
                                onClick={handleLogout}
                                className="flex-1 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-[13px] font-semibold transition cursor-pointer shadow-sm flex items-center justify-center gap-1.5 disabled:opacity-60"
                            >
                                {isLoggingOut ? (
                                    <>
                                        <Loader2 className="h-4 w-4 animate-spin" />
                                        <span>Logging out...</span>
                                    </>
                                ) : (
                                    <>
                                        <LogOut className="h-3.5 w-3.5" />
                                        <span>Log Out</span>
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ProfilePage;
